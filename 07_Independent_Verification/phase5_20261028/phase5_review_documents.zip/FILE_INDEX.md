# FILE_INDEX — phase5_review_documents.zip

생성: 2026-10-28 13:11 KST. 원본 파일은 수정하지 않고 복사만 했다. 프로젝트 루트: `/home/minju/faicpaston/Imputing_Missing_Data`

| ZIP 내 경로 | 실제 경로 | 역할 | 최종 수정 | 관련 가설 | sha256 |
|---|---|---|---|---|---|
| `results/notes/phase5_mathematical_foundations.md` | `/home/minju/faicpaston/Imputing_Missing_Data/results/notes/phase5_mathematical_foundations.md` | Gate A 수학 기초: 정의, 명제 1–6, 대칭, Takens 적용표, 미해결 목록 | 2026-10-28 10:18:34 | H1,H2,H3 (이론) | `2539a5dc716cca23` |
| `results/notes/phase5_hypothesis_protocol.md` | `/home/minju/faicpaston/Imputing_Missing_Data/results/notes/phase5_hypothesis_protocol.md` | 사전 등록 프로토콜(10:50 고정, §9 변경 기록, §10 Gate F) | 2026-10-28 10:46:27 | H1,H2,H3,Gate F | `922387ac7d718e36` |
| `results/notes/phase5_controlled_experiment_results.md` | `/home/minju/faicpaston/Imputing_Missing_Data/results/notes/phase5_controlled_experiment_results.md` | Gate E/F 결과 보고(사전 등록 + 사후 탐색 구분) | 2026-10-28 12:37:09 | H1,H2,H3,Gate F | `82e6c0a4f45c8d53` |
| `results/notes/phase5_observability_information_audit.md` | `/home/minju/faicpaston/Imputing_Missing_Data/results/notes/phase5_observability_information_audit.md` | Gate C 관측 수준 감사(국소 Jacobian, 대칭, 전역 모호성, 물리 기준) | 2026-10-28 10:42:21 | H1 (관측 정보), Q1 | `db0fc0a590ba4824` |
| `research_handover_latest.md` | `/home/minju/faicpaston/Imputing_Missing_Data/research_handover_latest.md` | 인수인계 진입점 (패키지 생성 직전 버전) | 2026-10-28 12:37:49 | 전체 | `610aa5dd0b19187b` |
