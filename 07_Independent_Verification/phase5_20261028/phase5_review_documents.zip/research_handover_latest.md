# Research Handover — LATEST

**갱신 시각:** 2026-10-28 13:00 KST. **현재 게이트:** Gate A–F 완료. 결과: `results/notes/phase5_controlled_experiment_results.md`.
- 이 파일이 다음 세션(Claude Code / ChatGPT)의 진입점이다.
- 이정표마다 스냅샷을 `results/notes/handover_snapshots/`에 남긴다.
- 이전 음성 결과와 미해결 이의는 지우지 않는다.

## 1. 연구 정체성

**공식 AIM**
> 완전 관측 변수 없이 다변량 시계열의 결측을 복원하는 동역학 기반 대치 프레임워크. Takens 정리가 시사하듯 모든 변수의 지연 매장이 일관되게 사상되는 공유 잠재 상태를 학습한다.

**중심 질문**
- 여러 불완전 지연 관측을 통합해, 기준 변수 없이 기저 동역학 상태의 일관된 표현을 학습할 수 있는가?

**현재 가설** (`results/notes/phase5_hypothesis_protocol.md`, 10:50 고정, 변경 기록 §9)
- **H1 (관측 수준 상보성):** κ = 1, p = 0.7에서 상대 view가 자기 hidden y_j에 대해 제곱오차 정보를 더한다.
- **H2 (주 가설, 학습 활용):** 상대 view를 입력으로 받는 AE 잠재(Arm B)가 자기 하위계만 받는 AE 잠재(Arm A)보다 y_j를 더 잘 decoding하게 한다. 두 Arm의 복원 목표는 같다.
- **H3 (공유 상태 일관성):** 하나의 readout이 허용 마스크(L_j ≥ 2)들에서 정확하고 안정적이다.
- **음성 대조:** κ = 0에서 H1과 H2의 개선은 0이어야 한다.

## 2. 수학적 기초 (`results/notes/phase5_mathematical_foundations.md`)

**정의**
- 상태공간: R⁶. 흡수 공이 존재하고(증명함), 대역 끌개 A_κ는 프랙탈이며 다양체가 아니다.
- 관측: x1, z1, x2, z2의 좌표 사영. generic하지 않다.
- 지연: m = 8, τ = 0.05.
- 마스크: 전체 격자에서 항목별 MCAR을 만든 뒤 창을 자른다.

**증명한 명제**
- 명제 1: 결정론적 식별 불가능성(점별).
- 보조정리 S: Γ×Γ와 P는 모든 κ에서 대칭이고, Γ×Id는 κ = 0에서만 대칭이다.
- 따름정리 1: z-only 마스크는 모든 κ에서 전역 2:1이다.
- 따름정리 2: κ = 0, x_j 미관측이면 상대 view와 무관하게 부호를 식별할 수 없다.
- 따름정리 3: 대칭 측도 하에서 해당 층의 Bayes 추정은 0이다.
- 명제 2: L² 사영 항등식. 조건부 의존성만으로는 위험이 줄지 않는다는 반례 포함.
- 명제 3: κ = 0에서 상대 view의 Bayes 개선은 0이다. 곱 측도와 MCAR 가정이 필요하다.
- 명제 5: y_j = x_j + (ẋ_j − κ(x_o − x_j))/σ. κ = 1에서는 상대 view의 **현재 값**만으로 자명한 이득이 생길 수 있다.
- 명제 6: 잠재는 원 입력보다 정보를 늘리지 못한다(자료처리 부등식).
- §7: H3 정의. 공유 readout을 쓰고, 잠재 재매개변수화에 불변이다. 잠재의 일치는 필요조건이 아니다.

**알려진 반례**
- z-only 창은 국소적으로 full-rank이지만 전역 비단사다(Gate C에서 수치 확인).
- h±(Phase 4)도 같은 성격의 반례다.

**국소 vs 전역**
- R⁶ 기준의 full rank는 근방 단사를 함의한다.
- 전역 단사, 균일 Lipschitz 역, 미분동형은 증명되지 않았다.

**미해결** (MF §8)
- κ = 1의 SRB 측도와 대칭.
- κ = 1, L0 층에서 부호 식별 여부.
- 좌표 관측의 전역 단사성.
- encoder의 단사성.

## 3. 저장소와 코드 상태

**Git과 경로**
- **Git: 저장소가 아니다**(`git status` → not a git repository). 버전은 파일별 code_md5로 기록한다.
- 루트: `/home/minju/faicpaston/Imputing_Missing_Data`
- Python: `~/.conda/envs/reef_gpu/bin/python`, `PYTHONPATH=.pydeps:.`
- 원본 공통 모듈: `src/` (수정하지 않음).
- 이전 실험: `experiments/{fdr, coupled, aim_autonomous, external}`, `results/extra/phase3*/phase4*`.

**Phase 5 코드: `experiments/phase5/`**

| 파일 | 역할 |
|---|---|
| `gen_data.py` | 독립 궤적 생성 |
| `obs_audit.py` | Gate C |
| `core.py` | Arm 정의, 자료 조립, ArmModel(FDR-Learned, 입출력 view 분리), 직렬 인코딩 |
| `train.py` | Arm 하나를 학습 |
| `run_lane.sh` | setsid lane. 마감 시각 guard 포함 |
| `evaluate.py` | probe, H3, 동역학, 대치 |
| `eval_scheduler.py` | 증거 기반 평가 실행기 |
| `h1_capacity.py` | H1 용량 민감도 |
| `analyze.py` | 사전 등록된 분석 |
| `analyze_posthoc.py` | **사후 탐색**(B − Sham, κ DiD). 확증 근거로 쓰지 않음 |
| `external.py` | Gate F 전처리, 학습(MV/MVshift/SV_k), 기준선, 채점 |
| `analyze_external.py` | Gate F 사전 등록 분석(seed별 주 블록 bootstrap) |
| `tests/test_phase5.py`, `tests/test_external.py` | 무결성 테스트 8 + 3개, 모두 통과 |

**Phase 5 자료와 결과: `results/extra/phase5/`**
- `data/k{κ}_id{j}.npz`: κ ∈ {0, 1}. train 0–7(20k), val 100–107(5k), test 200–209(5k).
- `gateC/`: 국소 Jacobian, 대칭, 전역 모호성, 물리 기준.
- `runs/{ckpt, logs, rows, lanes}`: 학습 산출물.
- `eval/`, `h1/`, `analysis/`(사후 탐색은 `analysis/posthoc_exploratory.csv`).
- `external/`: Gate F 블록별 SSE/N npz, `external/analysis/{contrasts,levels,summary}.csv`.
- 전처리 자료: `Data/external/{beijing,jena}/processed/*.npz`(원자료는 해시로 무변경 확인).

**외부 자료**
- `Data/external/{jena, appliances, beijing}/raw` (읽기 전용).
- 감사: `results/notes/phase5_external_dataset_audit.md`.

## 4. 완료한 작업 (Phase 5, 2026-10-28)

- **Gate A** 수학 문서 작성.
- **Gate B** 기존 코드 점검(§6) + 새 코드 테스트 8개.
- **Gate C** 관측 수준 감사(`phase5_observability_information_audit.md`).
- **Gate D** 파일럿: κ = 1, p = 0.7, r = 0의 9 Arm.
  - 버그 2개를 수정했다: A2의 출력 인덱스, lane의 rc 기록.
  - 학습은 안정적이었다: 비유한 0, 상한 도달 0, 42–160초.
  - test 수치는 보지 않았다.
- **Gate E 완료** (12:21): 학습 304개(모두 rc = 0, 비유한 0, 상한 도달 0, 34.9 GPU·h), 평가 36/36, H1 용량 4개, 사전 등록 분석.
- **Gate F 완료** (12:18): Beijing, Jena × p {0.3, 0.7} × seed 3 × (MV, MVshift, SV_k), 102개 rc = 0, 기준선 포함.
- 재실행 명령:
  - `PYTHONPATH=.pydeps:. python experiments/phase5/analyze.py`
  - `python experiments/phase5/analyze_external.py`
  - `python experiments/phase5/analyze_posthoc.py`

**Gate E/F 핵심 결과** (상세: `phase5_controlled_experiment_results.md`)
- **H2 주 대비 B − A (κ = 1, p = 0.7): +0.0137, t-CI [−0.0015, +0.0288], 1/8 → inconclusive. 지지되지 않음.** 점추정은 반대 방향이다.
- κ = 1, p = 0.3: B − A = −0.0128(8/8). 검출되지만 δ = 0.02보다 작다.
- κ = 0 음성 대조: B − A = +0.023(p = 0.7). B가 나쁘다.
- Sham − A = +0.020 ~ +0.029(p = 0.7). **입력 열 추가 자체의 비용**이다.
- 사후 탐색: κ = 1에서 B − Sham = −0.015(8/8), κ = 0에서는 약 0. 결합 정보는 작게 쓰이지만 입력 비용에 가려진다. **확증 아님.**
- L0 층(κ = 1, p = 0.7): B − A = −0.028(8/8). 그러나 RMSE가 약 1.0이라 거의 복원되지 않는다.
- p = 0.3의 L0 층은 표본이 j당 2–3개라 해석할 수 없다.
- H1: raw_joint는 own보다 나쁘다. 폭을 키우면 더 나빠진다(추정량 실패, DPI상 정보는 음수가 아님). → Bayes 수준은 Unresolved.
- H3: y_j 공유 readout은 p = 0.3에서 정확하다(약 0.04). p = 0.7에서는 마스크 간 분산이 약 0.13–0.18이고, s_j의 ridge 복원 오차는 0.44 이상이다. 강한 H3는 기각.
- latent가 raw 특징보다 낫다(전 조건 8/8). DPI상 정보 생성이 아니라 표현 효율이다.
- 학습 seed 변동(약 ±0.01)이 주 효과 크기와 비슷하다.
- **Gate F 사전 기준 충족:** Beijing p = 0.7에서 MV − MV-shift = −0.137, 3/3 seed CI < 0. g가 길수록 이득이 커진다(g ≥ 8에서 −0.386).
  - Jena에서도 모두 음수다.
  - 단일 궤적이다. past-only MV는 미래를 쓰는 선형 보간보다 나쁘다.

**Gate C 주요 결과**
- Γ×Γ는 κ = 1에서 정확한 대칭이다(잔차 0). Γ×Id는 1 시간단위 안에 잔차 30이다.
- z-only 이웃의 49–50%가 y의 부호가 반대다.
- κ = 1 물리 항등식: x_o(t)를 쓰면 y 오차가 0.113 → 0.061이다(과거만 쓰는 2차 차분). 효과 크기 δ = 0.02보다 크다. 즉 **κ = 1의 상대 view 이득은 순간 항등식으로 예상되는 결과다.**
- κ = 1, 자기 창 L0의 y1 국소 증폭은 168이다. 상대 view를 더하면 5.4(MCAR) 또는 0.53(완전)이다.
- κ = 1 궤적마다 부호 점유율이 0.34–0.70으로 크게 다르다. 그래서 test 궤적 10개를 쓴다.

## 5. 알려진 오류와 무효화된 결과

**이전 Phase에서 발견된 문제 (memory와 notes)**
- FPRM 테스트를 다시 돌리지 않은 문제.
- GP plateau.
- P9 오류.
- 이전 held-out ELBO가 조건부 ELBO가 아니었던 문제.
- Phase 3C의 "FDR 일관성 우위"는 관측 좌표에서 나온 것이었다(3D-1).
- future-y 분할 경계 누출(영향 ≤ 2.3e-4).
- Phase 4 view 제거 평가가 OOD였다. **이번 Arm A/B 설계로 대체했다.**

**Phase 5에서 발견된 것**
- A2 출력 인덱스 버그(파일럿에서 발견하고 수정, 회귀 테스트 추가).
- lane rc 기록 버그(수정).

**설계로 해결한 점**
- **모델 선택에 참값을 쓰지 않는다.** val 궤적에서 관측 항목을 가려 기준으로 쓴다. 이전 Phase는 평가 결측 위치의 참값으로 조기 종료했다.

**남은 우려**
- Arm마다 모수 수가 다르다(A 31.5k, B 46.3k, C 57.8k).
- Sham은 κ = 1에서 분포 이동이 있다.
- **입력 열 비용이 B − A를 지배한다**(Sham − A > 0). 이를 보정하는 비교(B − Sham)는 사후 탐색일 뿐이다.
- 조기 종료 기준(val 관측 재구성)은 y_j decoding의 대리 지표가 아니다.

## 6. Gate B — 기존 코드 점검 요약

| 항목 | 결과 |
|---|---|
| 마스크 생성 | 전체 격자 MCAR → 창 절단. 겹치는 창의 일관성 OK [Verified (code)] |
| delay 정렬 | lag k = index k, past-only, 앞쪽 패딩은 미관측으로 처리 [Verified (code), Phase 5 past-only 테스트] |
| 손실 | FDR 다중도 보정 1/c(u)는 기존 tests로 확인. Phase 5에서는 목표 열에만 적용함을 테스트로 확인 |
| 정규화 | train 관측 항목만 사용 [Verified (code)] |
| view 제거 | Phase 4는 OOD였다 → Arm 설계로 대체 |
| 관측/결측 위치 혼합 | Phase 3D-1에서 발견. Phase 5 대치는 결측 위치만, probe는 마스크와 무관한 상태 목표 |
| 분할 경계 | Phase 5는 독립 궤적으로 분리해 경계 문제를 없앴다. 동역학 probe도 같은 궤적 안에서 t + 5만 쓴다 |
| FDR 다중도 가중 | lag-0의 실효 가중이 약 12%다(3D-1). Phase 5 주 지표는 probe라서 lag-0 대치는 부차 지표다 |

## 7. 대기 중인 작업
- 실행 중인 GPU 작업은 없다. 승인됐지만 실행하지 않은 것도 없다.
- **제안 (미승인, 새 사전 등록 필요):**
  1. 새 독립 복제본(train id 8–15)에서 **B − Sham을 주 대비**로 사전 등록해 확증한다.
  2. H1 하한을 구조화 추정량(마스크 패턴별 모델, 물리 항등식 기반)으로 다시 시험한다.
  3. Gate F에 양방향(비 past-only) 변형을 두고, 미래 사용 기준선과 공정하게 비교한다.

## 8. 과학적 해석 (Gate E/F 후)
- **H2: 지지되지 않음**(사전 등록 주 대비 inconclusive, 점추정 반대 방향).
- **H1:** 검출되지 않음(추정량의 한계). Bayes 수준은 Unresolved.
- **H3:** 강한 형태는 기각. 약한 형태(p = 0.3에서 y_j)만 성립.
- **κ = 0 대조:** 정보 0과 일관된다(B ≈ Sham).
- **실제 자료:** 정렬된 multi-view의 예측 이득은 경험적으로 확인됐다. 숨은 상태 복원의 증거는 아니다.
- **지지되지 않는 주장:**
  - 미분동형 대응
  - 전역 식별가능성
  - "잠재가 상태를 발견했다"
  - "multi-view 결합이 coupled 계에서 hidden 상태 복원을 개선한다"(p = 0.7)

## 9. 다음 세션 지시
- **먼저 읽을 파일:**
  1. 이 파일
  2. `phase5_mathematical_foundations.md`
  3. `phase5_hypothesis_protocol.md`
  4. `phase5_observability_information_audit.md`
  5. `phase5_controlled_experiment_results.md`
- **하지 말 것:**
  - 프로토콜을 사후에 바꾸는 것
  - 불리한 복제본을 제외하는 것
  - 원본 자료, 이전 체크포인트, 이전 결과를 수정하는 것
  - 미분동형을 주장하는 것
  - 예약 없이 GPU를 쓰는 것
