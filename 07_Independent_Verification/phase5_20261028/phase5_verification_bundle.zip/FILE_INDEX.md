# FILE_INDEX — phase5_verification_bundle.zip

생성: 2026-10-28 13:11 KST. 프로젝트 루트 `/home/minju/faicpaston/Imputing_Missing_Data`. ZIP 내 경로 = 프로젝트 루트 기준 실제 상대 경로.
원본은 수정하지 않고 복사만 했다. 파일별 sha256·크기·mtime은 `MANIFEST.json`에 있다. 새 연구 결론은 포함하지 않는다.

## 읽는 순서 (검증 경로)
1. 주 대비 H2 (κ=1, p=0.7, B−A): `experiments/phase5/analyze.py` → `results/extra/phase5/analysis/contrasts_probe_mlp.csv` (원본: `eval/*_probe.csv`, feature A1/A2/B1/B2, probe mlp0/mlp1, target y1/y2)
2. 복제본별 값: `analyze_posthoc.py` 의 R 테이블(복제본×Arm RMSE)을 같은 원본에서 재계산; 학습 seed 변동은 `seed_variability.csv`
3. B−Sham(사후 탐색, 사전 등록 아님): `analyze_posthoc.py` → `posthoc_exploratory.csv`
4. H1: `contrasts_probe_mlp.csv`(raw_* 특징) + `h1/*.csv`; 관측 수준 근거 `gateC/*`
5. H3: `eval/*_h3.csv` → `analysis/h3_*.csv`
6. Gate F: `external/*.npz` → `analyze_external.py` → `external/analysis/*.csv`
7. 실행 무결성: `analysis/training_rows.csv`, `runs/rows`, `runs/lanes/*.log`, `external/lanes/*.log`, `eval/scheduler.log`, 테스트 코드

## 파일 이름 규칙
- `eval/k{κ}_p{p}_r{복제본}_s{학습seed}_{probe|h3|dyn|imp}.csv`: 주 복제본은 s = r, 추가 seed는 r0의 s1, s2.
- `runs/*/k{κ}_p{p}_r{r}_{Arm}_s{seed}`: Arm ∈ A1,A2,B1,B2,Bcur1,Bcur2,C,Sham1,Sham2.
- `external/{ds}_p{p}_s{seed}_{model}.npz`: SSE, N 배열 (주 블록, 변수, 결측길이 층 g∈{1,2–3,4–7,≥8}).

## 파일 목록

| 실제 경로 (패턴) | 파일 수 | 역할 | 생성/수정 시점 범위 | 관련 가설 |
|---|---|---|---|---|
| `results/extra/phase5/eval/*_probe.csv` | 36 | 원본 평가: 잠재/원시 특징별 MLP·ridge probe의 test 궤적×층별 SSE/N (y_j, s_j) | 2026-10-28 10:39:47 ~ 2026-10-28 12:21:12 | H1,H2,B−Sham(사후) |
| `results/extra/phase5/eval/*_h3.csv` | 36 | 원본 평가: 공유 readout의 마스크 5개별 오차와 분산 | 2026-10-28 10:39:48 ~ 2026-10-28 12:21:12 | H3 |
| `results/extra/phase5/eval/*_dyn.csv` | 36 | 원본 평가: y_j(t+5) 동역학 probe | 2026-10-28 10:39:48 ~ 2026-10-28 12:21:12 | 2차 결과 |
| `results/extra/phase5/eval/*_imp.csv` | 36 | 원본 평가: 자기 view 결측 위치 대치 SSE/N | 2026-10-28 10:39:48 ~ 2026-10-28 12:21:12 | 2차 결과(H2 보조) |
| `results/extra/phase5/eval/scheduler.log` | 1 | 평가 스케줄러 실행 로그(36/36, rc) | 2026-10-28 12:21:46 | 실행 무결성 |
| `results/extra/phase5/analysis/contrasts_probe_mlp.csv` | 1 | 사전 등록 대비표(주 대비 H2 포함): 평균, t-CI 95/90, Wilcoxon, crossed bootstrap, 판정 | 2026-10-28 12:34:00 | H1,H2 |
| `results/extra/phase5/analysis/levels_probe_mlp.csv` | 1 | Arm/특징별 수준(복제본 평균·SD) | 2026-10-28 12:34:00 | H1,H2 |
| `results/extra/phase5/analysis/levels_ridge.csv` | 1 | ridge readout 수준(y, s) | 2026-10-28 12:34:00 | H2,H3 |
| `results/extra/phase5/analysis/h3_contrasts.csv`, `results/extra/phase5/analysis/h3_levels.csv` | 2 | H3 수준과 대비 | 2026-10-28 12:34:01 ~ 2026-10-28 12:34:01 | H3 |
| `results/extra/phase5/analysis/dyn_levels.csv` | 1 | 동역학 probe 수준 | 2026-10-28 12:34:01 | 2차 결과 |
| `results/extra/phase5/analysis/imputation_per_rep.csv` | 1 | 대치 RMSE 복제본별 | 2026-10-28 12:34:00 | 2차 결과 |
| `results/extra/phase5/analysis/contrasts_imputation.csv` | 1 | 대치 대비 | 2026-10-28 12:34:00 | 2차 결과 |
| `results/extra/phase5/analysis/seed_variability.csv` | 1 | 학습 seed만의 변동(복제본 0, seed 0/1/2) | 2026-10-28 12:34:01 | H2 (변동 추정) |
| `results/extra/phase5/analysis/training_rows.csv` | 1 | 학습 304개 요약(파라미터 수, best_val, epoch, cap, nonfinite, code_md5, cfg) | 2026-10-28 12:34:01 | 실행 무결성 |
| `results/extra/phase5/analysis/posthoc_exploratory.csv` | 1 | 사후 탐색 결과: B−Sham, B−A, Sham−A 및 κ DiD (사전 등록 아님) | 2026-10-28 12:35:25 | B−Sham(사후) |
| `results/extra/phase5/h1/*` | 8 | H1 용량 연구: 8궤적 합동, 폭 64/256/1024, 특징 own/joint/owncur/cur, test 궤적×층별 SSE/N 및 로그 | 2026-10-28 10:44:26 ~ 2026-10-28 10:46:45 | H1 |
| `results/extra/phase5/gateC/*` | 6 | Gate C 관측 감사 산출물(국소 Jacobian, 대칭, 자료 점검, 물리 기준, 전역 모호성) | 2026-10-28 10:21:58 ~ 2026-10-28 10:22:03 | H1/Q1 (관측 수준) |
| `results/extra/phase5/external/*.npz` | 138 | Gate F 원본 평가: 모델별 주 블록×변수×결측길이 층 SSE/N (MV/MVshift/SV_k/기준선; info=학습 메타) | 2026-10-28 10:45:48 ~ 2026-10-28 11:54:19 | Gate F |
| `results/extra/phase5/external/analysis/contrasts.csv`, `results/extra/phase5/external/analysis/levels.csv`, `results/extra/phase5/external/analysis/summary.csv` | 3 | Gate F 분석 결과(대비, 수준, 요약) | 2026-10-28 12:19:14 ~ 2026-10-28 12:19:14 | Gate F |
| `results/extra/phase5/external/lanes/*` | 17 | Gate F 작업 목록과 lane 로그(rc) | 2026-10-28 10:45:47 ~ 2026-10-28 11:54:20 | Gate F 실행 무결성 |
| `results/extra/phase5/runs/rows/*.csv` | 304 | 학습 1개당 결과 행(설정, best_val, epoch, md5, GPU) | 2026-10-28 10:25:11 ~ 2026-10-28 12:17:41 | 실행 Manifest |
| `results/extra/phase5/runs/logs/*.csv` | 304 | 학습 1개당 epoch 로그 | 2026-10-28 10:25:11 ~ 2026-10-28 12:17:41 | 실행 Manifest |
| `results/extra/phase5/runs/lanes/*` | 61 | Gate E 작업 목록(main_jobs.txt, part 파일)과 lane 로그(rc) | 2026-10-28 10:24:05 ~ 2026-10-28 12:17:42 | 실행 Manifest |
| `experiments/phase5/analyze.py` | 1 | 사전 등록 분석 스크립트(H1/H2/H3, 판정 규칙, δ=0.02) | 2026-10-28 10:43:10 | H1,H2,H3 |
| `experiments/phase5/analyze_posthoc.py` | 1 | 사후 탐색 분석(B−Sham, κ DiD) — 사전 등록 아님 | 2026-10-28 12:35:24 | B−Sham(사후) |
| `experiments/phase5/analyze_external.py` | 1 | Gate F 사전 등록 분석(seed별 주 블록 bootstrap) | 2026-10-28 12:18:51 | Gate F |
| `experiments/phase5/core.py` | 1 | Arm 정의(arm_spec), 자료 조립, 정규화, 마스크, ArmModel, seed_of | 2026-10-28 10:36:23 | H2 설계 |
| `experiments/phase5/train.py` | 1 | Arm 학습(CFG, FDR 손실, 참값 없는 조기 종료) | 2026-10-28 10:23:49 | H2 설계 |
| `experiments/phase5/evaluate.py` | 1 | probe/H3/동역학/대치 평가 | 2026-10-28 10:25:45 | H1,H2,H3 |
| `experiments/phase5/h1_capacity.py` | 1 | H1 용량 연구 | 2026-10-28 10:41:11 | H1 |
| `experiments/phase5/gen_data.py` | 1 | 독립 궤적 생성(SEED_BASE 20261028) | 2026-10-28 10:15:32 | 자료 |
| `experiments/phase5/obs_audit.py` | 1 | Gate C 관측 감사 | 2026-10-28 10:21:52 | Q1/H1 |
| `experiments/phase5/external.py` | 1 | Gate F 전처리·학습·shift·채점 | 2026-10-28 10:45:14 | Gate F |
| `experiments/phase5/eval_scheduler.py` | 1 | 평가 스케줄러 | 2026-10-28 10:40:40 | 실행 |
| `experiments/phase5/run_lane.sh` | 1 | Gate E lane 실행기 | 2026-10-28 10:36:23 | 실행 |
| `experiments/phase5/run_lane_cmd.sh` | 1 | Gate F lane 실행기 | 2026-10-28 10:45:47 | 실행 |
| `experiments/phase5/tests/test_phase5.py` | 1 | 무결성 테스트 8개(마스크 동일, hidden 미입력, train 정규화, past-only, Bcur, Sham, 손실 목표) | 2026-10-28 10:36:23 | 무결성 |
| `experiments/phase5/tests/test_external.py` | 1 | Gate F 무결성 테스트 3개(shift, 제외, 층) | 2026-10-28 10:45:29 | 무결성 |
| `experiments/fdr/loss.py` | 1 | 의존 모듈: fdr_masked_loss, sample_hide | 2026-10-27 12:02:57 | H2 설계 |
| `src/models.py` | 1 | 의존 모듈: group_mlp, mlp | 2026-10-24 19:26:22 | H2 설계 |
| `src/lorenz.py` | 1 | 의존 모듈: Lorenz 적분 | 2026-10-24 19:25:44 | 자료 |
| `src/delay_embedding.py` | 1 | 의존 모듈: 지연 매장 | 2026-10-24 19:25:44 | 자료 |

## 제외한 파일 (해시만 MANIFEST.json에 기록)
- 학습 궤적 `results/extra/phase5/data/*.npz` (52개) 및 외부 전처리 시계열 `Data/external/*/processed/*.npz`: 재생성 가능, sha256 기록.
- 체크포인트 `results/extra/phase5/runs/ckpt/` (304개, 55.7 MB).
- 외부 원자료 `Data/external/*/raw` (읽기 전용, 감사 문서 참고).

## 재실행
- `PYTHONPATH=.pydeps:. python experiments/phase5/analyze.py`
- `python experiments/phase5/analyze_posthoc.py`
- `python experiments/phase5/analyze_external.py`
- `python experiments/phase5/tests/test_phase5.py; python experiments/phase5/tests/test_external.py  (스크립트 실행, 궤적/외부 자료 필요)`

## 주의 (기존 문서에 이미 기록된 사항의 재기술, 새 결론 아님)
- 사전 등록 분석의 판정 함수는 TOST를 OPPOSITE보다 먼저 검사한다(결과 문서 §1 메모).
- `posthoc_exploratory.csv`와 `analyze_posthoc.py`는 주 결과를 본 뒤 작성되었다.
- 파일럿 9개 학습은 code_md5 f859de28 (A2 출력 인덱스 수정 전), 나머지는 a293c037 (프로토콜 §9).

## 패키지 생성 시 재현 점검 (2026-10-28 13:10–13:15, CPU)
- 이 ZIP만 풀어 `analyze_posthoc.py` 실행 → `posthoc_exploratory.csv` 원본과 바이트 동일.
- 이 ZIP만 풀어 `analyze_external.py` 실행 → `external/analysis/{contrasts,levels,summary}.csv` 원본과 바이트 동일.
- `analyze.py`는 ZIP 내 `eval/*.csv`만 사용한다(이번 점검에서는 재실행하지 않음, 원 실행 약 4분 20초).
- 무결성 테스트는 궤적 자료(`results/extra/phase5/data/*.npz`, 제외됨)가 필요하다. `python experiments/phase5/gen_data.py`로 재생성 후 `python experiments/phase5/tests/test_phase5.py`(8) 및 `test_external.py`(3, 외부 원자료 필요). 원 프로젝트에서 13:13에 다시 실행해 11/11 PASS 확인.
- 실행 환경: `PYTHONPATH=.` (`.pydeps`는 포함하지 않았다; torch, numpy, pandas, scipy 필요).
