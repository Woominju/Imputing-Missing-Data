# FILE_INDEX — phase6_review_documents.zip

생성: 2026-10-28 21:16 KST. 원본 파일을 수정하지 않고 복사만 했다. 프로젝트 루트: `/home/minju/faicpaston/Imputing_Missing_Data`. ZIP 내 경로 = 프로젝트 루트 기준 실제 상대 경로.

| ZIP 내 경로 | 역할 | 최종 수정 | 크기(B) | SHA-256 |
|---|---|---|---|---|
| `results/notes/phase6_mathematical_errata.md` | G0 정오표: E1–E9, 명제 E3.1(κ=0 Real–Sham 교환가능성), Sham donor 감사(E6), MV-shift(E7) | 2026-10-28 14:56:01 | 24243 | `bb88db8f5cb5d18e65c0aebe279ebf1c28aff516d6bb862ba9b2cc6b92dd7889` |
| `results/notes/phase6_g1_protocol.md` | G1 사전 등록(15:08 고정): 명제 G1.1–G1.6(대칭, L0의 E[y|U]=0, 층 분해, 인증 부등식, witness), 추론 단위 | 2026-10-28 15:08:31 | 10700 | `d4632a20d1ce6f8fc0e7cd4fd14d330cad6f18a38b0cbb0ad2337fe324e82db2` |
| `results/notes/phase6_g1_results.md` | G1 결과: L0 인증량·LCB, L0c0/L0c1, witness, 구조 감사 | 2026-10-28 15:27:26 | 8964 | `712edb39e822ded7d909c90ac91733281740fd2a16d882c13eac553c68f90d20` |
| `results/notes/phase6_g2_g3_protocol.md` | G2/G3 사전 등록(15:04 고정), §9 변경 기록, §10 S1R 추가 사전 등록(20:10) | 2026-10-28 20:08:42 | 13422 | `16cd8c40502d4b1e62189d43a9c918c9712f23318c459058431d7744ee00cab2` |
| `results/notes/phase6_g2_g3_results.md` | G2/G3 결과, κ=0 음성 대조 실패, 사후 진단 J/S(§5), S1R(§6) | 2026-10-28 20:49:26 | 15913 | `8bc7e811fa45357d95828ddcf97ac06fcfe086afea5689908a6236076bfff76d` |
| `results/notes/phase6_final_report.md` | Phase 6 최종 보고 Q1–Q6, 사전 등록/사후 구분표 | 2026-10-28 20:50:35 | 11316 | `5b5aad55eb9c19c4d9e024637814121cba0c73fb5aaf04fc425ad165db2817d5` |
| `research_handover_latest.md` | 인수인계 진입점 (패키지 생성 직전 버전; 생성 기록 추가 전) | 2026-10-28 20:51:27 | 30483 | `e9b6b22387374044bb0188508dd921d599ebe6e3fc1e705a1d483c4d878fb9a3` |

동반 자료: `phase6_verification_bundle.zip` (코드, 원본 평가 CSV, 분석 CSV, 고정 기록). 근거 위치 안내는 그 ZIP의 FILE_INDEX.md §A에 있다.
