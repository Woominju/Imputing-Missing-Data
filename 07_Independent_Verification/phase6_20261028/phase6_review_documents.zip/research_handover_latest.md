# Research Handover — LATEST

**갱신 시각:** 2026-10-28 20:51 KST. **현재 단계:** **Phase 6 완료**(G0·G1·G2·G3, 사후 진단, 사전 등록 재현 S1R). 최종 보고: `results/notes/phase6_final_report.md`. 실행 중인 GPU 작업은 없다. 아래 §P6이 Phase 6 상태이고, §1–§10은 Phase 5 기록이다(지우지 않음).
- 이 파일이 다음 세션(Claude Code / ChatGPT)의 진입점이다.
- 이정표마다 스냅샷을 `results/notes/handover_snapshots/`에 남긴다.
- 이전 음성 결과와 미해결 이의는 지우지 않는다.

## P6. Phase 6 상태 (2026-10-28)

### P6.0 한눈에 보기 (다음 세션은 여기부터 읽는다)

**Official AIM (원문, §1과 같음)**
> 완전 관측 변수 없이 다변량 시계열의 결측을 복원하는 동역학 기반 대치 프레임워크. Takens 정리가 시사하듯 모든 변수의 지연 매장이 일관되게 사상되는 공유 잠재 상태를 학습한다.

**Phase 6 결론 (라벨 포함, 상세는 최종 보고)**
- **Q1 정보 존재(H1):**
  - κ = 1, p = 0.7에서 Δ* ≥ 0.0019 > 0, L0 층 ≥ 0.032 [Verified (math) + 단측 95% 통계적 하한, 추정 오차 가정 없음].
  - κ = 0에서는 0이다 [Verified (math)].
  - L1, L2+ 층(시각의 94%)은 Unresolved다.
- **Q2 모델 활용(H2):**
  - Real MV > Sham MV. S1R은 −0.0104 [−0.0141, −0.0068], 23/24, 음성 대조 통과로 **사전 등록 독립 확증**이다. p = 0.3에서는 −0.015, 24/24다. 모두 δ = 0.02 미만이다.
  - **원래 H2(B > A)는 두 독립 표본에서 지지되지 않는다**(B가 +0.012 나쁨). 입력 비용이 정보 이득보다 크다.
- **Q3 정보 경로:** L0c0(x_j 창 없음 + x_o(t) 결측)에서도 Δ* ≥ 0.027(LCB)이다. 순간 항등식과 현재값으로 설명되지 않는 **지연 관측 정보가 존재한다** [Verified (math) + LCB]. L0c1에서는 현재값 경로가 대부분이다.
- **Q4 공유 좌표(H3):** 아니오. 사전 기준을 만족한 AE 잠재가 없다. 자기 목표 AE는 상대 하위계를 버린다. 원시 결합 관측에는 6차원 정보가 있다(raw readout 0.08 / 0.37) [Empirical].
- **Q5:** 아래 P6.1 표와 최종 보고 Q5.
- **Q6 단일 기여:** 대칭으로 Bayes 위험을 정확히 아는 관측 층을 이용해, 다중 지연 관측의 숨은 상태 정보를 **추정 오차 가정 없이** 증명했다. 그리고 정보 존재(H1)와 모델 활용(H2)과 좌표 형성(H3)을 분리했다.

### P6.1 수학적으로 검증된 정리와 정확한 가정 (Phase 6에서 새로 추가/수정)

| 정리 | 가정 | 문서 |
|---|---|---|
| z-only 창은 **적어도** 2:1(κ = 0에서 적어도 4:1) | Γ×Γ(κ = 0에서 Z₂×Z₂) 등변성, Fix 밖의 점 | ER E1 |
| D는 X_T = Φ^T(R⁶)(T ≥ 0.35)와 A_κ 위에서 정의된다 | 순방향 흐름의 존재만 | ER E2 |
| 명제 E3.1: κ = 0, 독립 donor이면 E[B − Sham] = 0(추정량 수준), (B, Sham)은 교환 가능 | 하위계별 독립 초기조건, 동일 파이프라인, donor 독립 | ER E3 |
| 명제 3의 독립성은 고정 t에서 정확, 시간 혼합에서는 정상성 근사 | 독립 초기조건 | ER E4 |
| G1.1: 실험 법칙은 모든 t에서 Γ×Γ, P(κ = 0에서 Γ×Id)에 불변 | 생성기의 대칭 초기분포, 등변성. SRB 불필요 | G1 프로토콜 §2 |
| G1.2: L0에서 E[y_j \| U_j] = 0, R*(U \| L0) = E[y²]. κ = 0에서 Δ*_L0 = 0 | G1.1 + 마스크 독립 | 같음 |
| G1.3: Δ* = Σ P(s) Δ*_s ≥ p⁸ Δ*_L0 | 층이 σ(U)-가측(또는 마스크만의 함수) | 같음 |
| G1.4: 고정 f에 대해 Δ*_L0 ≥ E[y² − (y − f)² \| L0] | G1.2 | 같음 |
| G1.5–6: witness 부등식, 교차적합 편향 = 두 추정 오차의 곱 | Y ∈ L² | 같음 |

**반례와 식별 불가능 조건**
- z-only(모든 κ)
- 자기 L0 + 자기 view만(모든 κ)
- κ = 0 자기 L0 + 상대 view
- κ = 0에서 자기 view로 상대 하위계
- 국소 full rank ≠ 전역 단사(z-only 창)
- L2+는 대칭 반례만 배제하며, 식별가능 집합이 아니다

### P6.2 수정한 기존 명제 (Phase 5 문서는 덮어쓰지 않았다; 정오표 `phase6_mathematical_errata.md`)
- E1 2:1 → 적어도 2:1
- E2 D의 정의역
- E3 Bayes 대 추정량. PR §7 모순 조항 철회. κ = 0 B − A = 0 기대 철회
- E4 고정 t 대 시간 혼합
- E5 L2+ 명칭
- E6 Phase 5 Sham donor 재사용 → t-CI 확증 불가
- E7 MV-shift는 past-only가 아님
- E8 판정 라벨 분리
- E9 "충분하다" 철회

### P6.3 발견된 오류와 영향받는 실험
- **Phase 5 Sham donor 재사용(E6):** Phase 5 사후 B − Sham의 t-CI. 수치는 보존하고 해석만 약화했다.
- **Gate F MV-shift의 미래 노출(E7):** Gate F의 "정렬 이득" 해석을 "정렬을 깬 대조보다 낫다"로 좁혔다. MV-shift − SV 해석은 보류한다.
- **Phase 5 판정 함수 순서(E8):** B − A 라벨. Phase 6에서도 같은 현상이 재현됐다(EQUIV 라벨 + CI > 0).
- **Phase 6 실행 중 오류**
  - (1) 첫 seed base가 Phase 5 시드와 겹쳤다. 학습 전에 테스트가 잡았고 자료를 재생성했다.
  - (2) S1R 첫 lane이 SyntaxError로 학습 전에 모두 종료됐다. 수정 후 재실행했다.
  - 둘 다 결과에 영향은 없다.
- **Unresolved:** G2 κ = 0, p = 0.7 음성 대조 실패(+0.0062, 20/24).
  - 수치 결합은 배제했다(진단 J ≈ S ≈ 0).
  - 새 표본(진단 J, S1R)에서 재현되지 않았다.

### P6.4 미실행 실험과 이유
- Gate F 공정 대조 MV-lag: 제안만 했다(ER E7). GPU를 G1–G3, S1 확증에 우선 배정했다.
- 6차원 목표 AE(C형) G3 시험: 범위 밖(Arm 탐색 최소화). 다음 후보다.
- L1, L2+ 층의 Bayes 하한: R*(U)를 정확히 모르는 층이라 오차 가정 없이는 불가능하다.

### P6.5 다음 연구의 가장 중요한 질문
1. L1, L2+ 층에서 Δ* > 0인가? 추정 오차를 통제한 하한이 필요하다.
2. 학습 방식(마스크 증강, 표본 수)만 바꿔 입력 비용을 줄이면 Real MV의 이득이 순효과(B < A)로 나타나는가? 새 손실은 쓰지 않는다.
3. 6차원 목표 AE의 잠재는 공유 상태 좌표를 형성하는가?
4. G2 κ = 0 대조 실패의 원인.

### P6.6 새 세션에서 읽을 자료 (순서)
1. 이 파일 §P6
2. `results/notes/phase6_final_report.md`
3. `results/notes/phase6_mathematical_errata.md`
4. `results/notes/phase6_g1_protocol.md` → `phase6_g1_results.md`
5. `results/notes/phase6_g2_g3_protocol.md`(§10 S1R) → `phase6_g2_g3_results.md`
6. Phase 5 문서(§1–§10 아래)

### P6.7 Gate별 기록 (시간순)

**Phase 6 지시의 목표 (사용자 원문 요지)**
- Phase 5의 수학적 주장을 교정한다.
- 관측 정보의 존재(H1), 모델의 활용(H2), 공유 상태의 일관성(H3)을 분리해 검증한다.
- 우선순위: Mathematical validity → Identifiability → Experimental controls → Statistical inference → Scientific contribution.

**GPU**
- fai-L40S GPU 0, 1. 사용자가 10/29 00:39까지 연장했다(필요하면 사용자가 더 연장).
- 모든 작업은 `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0|1`로 실행한다.

**Gate G0 — 완료 (14:58)** → `results/notes/phase6_mathematical_errata.md`
- 점검 코드: `experiments/phase6/g0_checks.py` → `results/extra/phase6/g0/`
- E1: "정확히 2:1" → **적어도 2:1**(κ = 0에서는 Z₂×Z₂ 때문에 적어도 4:1). 섬유 크기는 Unresolved.
- E2: D(s)의 정의역. 역방향 흐름의 R⁶ 전역 존재는 증명되지 않았다. D는 X_T = Φ^T(R⁶)(T ≥ 0.35)와 A_κ 위에서만 정의한다.
- E3: Bayes 명제(명제 2, 3, 6)는 추정량의 기대 차이에 대한 정리가 아니다.
  - "κ = 0에서 B − A = 0이어야 한다"는 틀렸다. PR §7의 "모순" 조항도 틀렸다.
  - **새 명제 E3.1:** κ = 0, 독립 donor이면 E[B − Sham] = 0이 **추정량 수준에서 정확히** 성립한다.
- E4: 명제 3의 독립성은 고정 t에서는 정확하다. 시간 평균에서는 정상성 근사다.
- E5: L_j ≥ 2는 개수 기반 탐색적 층이다. "허용(식별가능) 마스크"라고 부르지 않는다.
- E6: **Phase 5 Sham donor는 다른 복제본/다른 test 대상의 실제 궤적이었다.**
  - B − Sham 복제본 대비는 독립이 아니다(κ = 1, p = 0.7에서 순환 ρ̂₁ = +0.43).
  - t-CI는 확증 근거가 아니다. 수치는 보존했다.
- E7: **Gate F MV-shift는 past-only 대조가 아니다.**
  - target view에 따라 다른 view 입력의 25–74%(Beijing)가 원래 시각 기준 미래(≥ 14일)다. 다른 view의 랩 경계는 제외되지 않았다.
  - 스트레스 실험으로만 인용한다. 공정 대조(MV-lag)는 제안만 했고 미실행이다.
- E8: 판정 라벨을 분리한다(방향 검출 / δ / 동등성).
- E9: MF §4의 "충분하다"를 "개수 조건만 만족"으로 고친다.

**Gate G1 — 완료** → 프로토콜 `results/notes/phase6_g1_protocol.md`(15:08 고정, 해시 `results/extra/phase6/PROTOCOL_FREEZE_g1.txt`)
- 새 수학(Verified math):
  - 생성기 법칙의 Γ×Γ, P 대칭(SRB 가정 불필요).
  - **L0 층에서 R*(U|L0) = E[y²]가 정확히 성립한다.** 따라서 임의의 고정 예측기 f로 Δ*_L0 ≥ E[y²|L0] − R(f|L0)이고, 이것은 추정 오차 가정 없는 통계적 하한이다.
  - Δ* ≥ p⁸ Δ*_L0.
  - 교차적합 witness의 편향 = 두 추정 오차의 곱.
- 코드: `experiments/phase6/g1_info.py`(κ ∈ {0, 1} × p ∈ {0, 0.3, 0.7}, 6개 작업). 출력: `results/extra/phase6/g1/`.
- **G1 완료 (15:27)** → `results/notes/phase6_g1_results.md`. 분석: `python experiments/phase6/analyze_g1.py`.
  - **κ = 1, p = 0.7: Δ*_L0 ≥ 0.032(단측 95%, test 궤적 32개), 따라서 Δ* ≥ 0.0019 > 0** [Verified (math) + 통계적 신뢰하한].
  - 정확한 null 넷(κ = 1 donor V, κ = 1 U 단독, κ = 0 V, κ = 0 Vc)은 모두 ≤ 0이다.
  - L0c0(x_o(t)도 결측)에서도 LCB 0.027이다. 이 정보는 순간 항등식이나 현재값이 아니라 **상대 view 지연 관측**에서 온다.
  - L1, L2+의 Bayes 개선은 Unresolved다. empirical 이득은 0.0006–0.003으로, null보다는 크다.
  - R*(U) ≥ p⁸ = 0.0576: 자기 창 Bayes 위험의 73% 이상이 대칭 모호성(L0)에서 온다.
  - 구조 감사: Phase 5 raw-MLP의 실패(joint가 더 나쁨)를 재현했고, 원인은 추정량이다(표본 수 + 고정 마스크). 새 마스크 증강 체제에서는 κ = 1 joint가 낫다(−0.005).
  - 모든 G1 예측기는 y로 학습한 Oracle-level 진단이다. AE 성능과 섞지 않는다.

**Gate G2/G3 — 완료** → 프로토콜 `results/notes/phase6_g2_g3_protocol.md`(15:04 고정, 해시 `PROTOCOL_FREEZE_g2g3.txt`)
- 새 독립 궤적(seed base 30261029, `experiments/phase6/gen6.py`, `results/extra/phase6/data/`).
- 복제본 24개/조건. 복제본마다 train/val/test 대상과 donor가 모두 독립이다. test 8개/복제본.
- Arm: A, Aslot(4-slot 용량 통제 own-only), B, Bcur, Sham × j = 1, 2. 조건 κ ∈ {0, 1} × p ∈ {0.3, 0.7}. 학습 960개.
- 주 대비 S1: **B − Sham (κ = 1, p = 0.7)**. 고정 순서는 S2(DiD p = 0.7) → S3(κ = 1, p = 0.3).
- 음성 대조: κ = 0의 B − Sham(정확히 0이 기대됨). δ = 0.02는 유지.
- G3: 공유 6차원 MLP readout, 독립 마스크 5개, 마스크만으로 정한 층과 Oracle σ_min 층을 분리, raw 기준선.
- 학습 lane: `results/extra/phase6/runs/lanes/main_lane{0..23}.log`(15:02 시작, 24 lane).
- 평가: `experiments/phase6/eval_sched6.py` → `results/extra/phase6/eval/`. Oracle Jacobian: `results/extra/phase6/jac/`.
- 테스트: `experiments/phase6/tests/test_phase6.py` 9/9 PASS(학습 전).
- 실행 중 확인된 사항:
  - 처음 정한 seed base(20261029)는 일부 test donor 시드가 Phase 5 κ = 1 시드와 겹쳤다. 테스트가 이를 잡았고, base를 30261029로 바꿔 Phase 6 자료를 전부 다시 생성했다. 이 자료는 그때까지 아무 데서도 쓰이지 않았다.
  - 복제본 수는 16에서 24로 늘렸다. 복제본마다 test 집합이 독립이라 복제본 간 SD가 커질 수 있어서다(검정력 근거는 프로토콜 §4). 두 변경 모두 학습 시작 전에 했다.
- **G2/G3 완료 (19:24)** → `results/notes/phase6_g2_g3_results.md`. 분석: `python experiments/phase6/analyze6.py` → `results/extra/phase6/analysis/`.
  - 무결성: 960 학습 rc = 0, 상한 도달 0, 비유한 0, md5 하나(`493f0b7f`). 평가 96/96.
  - S1 B − Sham(κ = 1, p = 0.7) = −0.0070 [−0.0116, −0.0024], 19/24. S2 DiD = −0.0132 [−0.019, −0.007]. S3(κ = 1, p = 0.3) = −0.0151 [−0.0162, −0.0139], 24/24. 모두 δ = 0.02 미만이다.
  - **음성 대조 κ = 0, p = 0.7이 실패했다:** B − Sham = +0.0062 [+0.0022, +0.0101], 20/24 양수(정확한 부호 검정 p ≈ 0.0015). 사전 규칙에 따라 **S1 결론은 보류**한다. κ = 0, p = 0.3 대조는 통과했으므로 **S3는 해석 가능한 독립 확증**이다.
  - 사후 진단(결합 적분 J 대 분리 적분 S, 학습 192개, `experiments/phase6/diag/`, `results/extra/phase6/diag_k0/`, 20:07 완료): J −0.0007 [−0.0060, +0.0046], S −0.0003 [−0.0054, +0.0047]. 수치 결합 가설은 기각했고, 원인은 Unresolved다.
  - **사전 등록 S1R**(프로토콜 §10, 20:10 고정, 학습 192개, `experiments/phase6/s1r/`, `results/extra/phase6/s1r/`, 20:48 완료):
    - κ = 1 B − Sham = **−0.0104 [−0.0141, −0.0068], 23/24**
    - κ = 0 대조 = +0.0009 [−0.0034, +0.0051], 통과
    - → **S1 독립 확증**(δ 미만)
  - 원래 H2(B − A, κ = 1, p = 0.7) = +0.0123 [0.0085, 0.0161]. 독립 표본에서도 B가 A보다 나쁘다. **지지되지 않는다.**
  - G3: 사전 기준(RMSE_s6 ≤ 0.2 ∧ 마스크 간 SD ≤ 0.1 ∧ raw보다 우수)을 만족한 AE 잠재가 **없다.**
    - 자기 목표 AE의 잠재는 상대 하위계를 거의 버린다(κ = 0에서 상대 RMSE 1.0, κ = 1에서 B만 0.42 / 0.92).
    - raw 결합 지연 관측 readout은 6차원을 p = 0.3에서 0.08, p = 0.7에서 0.37로 복원한다.
    - p = 0.7 오차의 대부분은 마스크 간 변동이다.

**재현 명령 (Phase 6)**
- `PYTHONPATH=.pydeps:. python experiments/phase6/gen6.py`
- `python experiments/phase6/tests/test_phase6.py`
- lane: `experiments/phase6/run_lane6.sh GPU results/extra/phase6/runs/lanes/main_part_Q.txt LOG`
- `python experiments/phase6/jac6.py 12`
- `python experiments/phase6/eval_sched6.py 4`
- `python experiments/phase6/g1_info.py K P`
- `python experiments/phase6/g0_checks.py`
- 분석: `python experiments/phase6/analyze_g1.py`, `python experiments/phase6/analyze6.py`, `python experiments/phase6/s1r/analyze.py`
- 사후 진단: `python experiments/phase6/diag/k0_gen.py 56` → `experiments/phase6/diag/run_lane_diag.sh` → `experiments/phase6/diag/k0_eval_loop.sh`
- S1R: `python experiments/phase6/s1r/gen.py 56` → `experiments/phase6/s1r/run_lane.sh GPU part LOG` → `experiments/phase6/s1r/eval_loop.sh` → `experiments/phase6/s1r/analyze.py`
- 모든 Python 명령은 `PYTHONPATH=.pydeps:.`와 `~/.conda/envs/reef_gpu/bin/python`으로 실행한다.

**코드 버전:** Git 저장소가 아니다. 파일 해시는 `results/extra/phase6/PROTOCOL_FREEZE_*.txt`, `results/extra/phase6/diag_k0/FREEZE.txt`, `results/extra/phase6/s1r/FREEZE.txt`에 있다. AE 학습 1,344개의 code_md5는 모두 `493f0b7f`다(행별 `runs/rows/*.csv`). Phase 5 코드와 결과는 수정하지 않았다(`experiments/phase6/`는 Phase 5 모듈을 import만 한다).

## 1. 연구 정체성

**공식 AIM**
> 완전 관측 변수 없이 다변량 시계열의 결측을 복원하는 동역학 기반 대치 프레임워크. Takens 정리가 시사하듯 모든 변수의 지연 매장이 일관되게 사상되는 공유 잠재 상태를 학습한다.

**중심 질문**
- 여러 불완전 지연 관측을 통합해, 기준 변수 없이 기저 동역학 상태의 일관된 표현을 학습할 수 있는가?

**현재 가설** (`results/notes/phase5_hypothesis_protocol.md`, 10:50 고정, 변경 기록 §9)
- **H1 (관측 수준 상보성):** κ = 1, p = 0.7에서 상대 view가 자기 hidden y_j에 대해 제곱오차 정보를 더한다.
- **H2 (주 가설, 학습 활용):** 상대 view를 입력으로 받는 AE 잠재(Arm B)가 자기 하위계만 받는 AE 잠재(Arm A)보다 y_j를 더 잘 decoding하게 한다. 두 Arm의 복원 목표는 같다.
- **H3 (공유 상태 일관성):** 하나의 readout이 허용 마스크(L_j ≥ 2)들에서 정확하고 안정적이다.
- **음성 대조:** κ = 0에서 H1과 H2의 개선은 0이어야 한다.

## 2. 수학적 기초 (`results/notes/phase5_mathematical_foundations.md`)

**정의**
- 상태공간: R⁶. 흡수 공이 존재하고(증명함), 대역 끌개 A_κ는 프랙탈이며 다양체가 아니다.
- 관측: x1, z1, x2, z2의 좌표 사영. generic하지 않다.
- 지연: m = 8, τ = 0.05.
- 마스크: 전체 격자에서 항목별 MCAR을 만든 뒤 창을 자른다.

**증명한 명제**
- 명제 1: 결정론적 식별 불가능성(점별).
- 보조정리 S: Γ×Γ와 P는 모든 κ에서 대칭이고, Γ×Id는 κ = 0에서만 대칭이다.
- 따름정리 1: z-only 마스크는 모든 κ에서 전역 2:1이다.
- 따름정리 2: κ = 0, x_j 미관측이면 상대 view와 무관하게 부호를 식별할 수 없다.
- 따름정리 3: 대칭 측도 하에서 해당 층의 Bayes 추정은 0이다.
- 명제 2: L² 사영 항등식. 조건부 의존성만으로는 위험이 줄지 않는다는 반례 포함.
- 명제 3: κ = 0에서 상대 view의 Bayes 개선은 0이다. 곱 측도와 MCAR 가정이 필요하다.
- 명제 5: y_j = x_j + (ẋ_j − κ(x_o − x_j))/σ. κ = 1에서는 상대 view의 **현재 값**만으로 자명한 이득이 생길 수 있다.
- 명제 6: 잠재는 원 입력보다 정보를 늘리지 못한다(자료처리 부등식).
- §7: H3 정의. 공유 readout을 쓰고, 잠재 재매개변수화에 불변이다. 잠재의 일치는 필요조건이 아니다.

**알려진 반례**
- z-only 창은 국소적으로 full-rank이지만 전역 비단사다(Gate C에서 수치 확인).
- h±(Phase 4)도 같은 성격의 반례다.

**국소 vs 전역**
- R⁶ 기준의 full rank는 근방 단사를 함의한다.
- 전역 단사, 균일 Lipschitz 역, 미분동형은 증명되지 않았다.

**미해결** (MF §8)
- κ = 1의 SRB 측도와 대칭.
- κ = 1, L0 층에서 부호 식별 여부.
- 좌표 관측의 전역 단사성.
- encoder의 단사성.

## 3. 저장소와 코드 상태

**Git과 경로**
- **Git: 저장소가 아니다**(`git status` → not a git repository). 버전은 파일별 code_md5로 기록한다.
- 루트: `/home/minju/faicpaston/Imputing_Missing_Data`
- Python: `~/.conda/envs/reef_gpu/bin/python`, `PYTHONPATH=.pydeps:.`
- 원본 공통 모듈: `src/` (수정하지 않음).
- 이전 실험: `experiments/{fdr, coupled, aim_autonomous, external}`, `results/extra/phase3*/phase4*`.

**Phase 5 코드: `experiments/phase5/`**

| 파일 | 역할 |
|---|---|
| `gen_data.py` | 독립 궤적 생성 |
| `obs_audit.py` | Gate C |
| `core.py` | Arm 정의, 자료 조립, ArmModel(FDR-Learned, 입출력 view 분리), 직렬 인코딩 |
| `train.py` | Arm 하나를 학습 |
| `run_lane.sh` | setsid lane. 마감 시각 guard 포함 |
| `evaluate.py` | probe, H3, 동역학, 대치 |
| `eval_scheduler.py` | 증거 기반 평가 실행기 |
| `h1_capacity.py` | H1 용량 민감도 |
| `analyze.py` | 사전 등록된 분석 |
| `analyze_posthoc.py` | **사후 탐색**(B − Sham, κ DiD). 확증 근거로 쓰지 않음 |
| `external.py` | Gate F 전처리, 학습(MV/MVshift/SV_k), 기준선, 채점 |
| `analyze_external.py` | Gate F 사전 등록 분석(seed별 주 블록 bootstrap) |
| `tests/test_phase5.py`, `tests/test_external.py` | 무결성 테스트 8 + 3개, 모두 통과 |

**Phase 5 자료와 결과: `results/extra/phase5/`**
- `data/k{κ}_id{j}.npz`: κ ∈ {0, 1}. train 0–7(20k), val 100–107(5k), test 200–209(5k).
- `gateC/`: 국소 Jacobian, 대칭, 전역 모호성, 물리 기준.
- `runs/{ckpt, logs, rows, lanes}`: 학습 산출물.
- `eval/`, `h1/`, `analysis/`(사후 탐색은 `analysis/posthoc_exploratory.csv`).
- `external/`: Gate F 블록별 SSE/N npz, `external/analysis/{contrasts,levels,summary}.csv`.
- 전처리 자료: `Data/external/{beijing,jena}/processed/*.npz`(원자료는 해시로 무변경 확인).

**외부 자료**
- `Data/external/{jena, appliances, beijing}/raw` (읽기 전용).
- 감사: `results/notes/phase5_external_dataset_audit.md`.

## 4. 완료한 작업 (Phase 5, 2026-10-28)

- **Gate A** 수학 문서 작성.
- **Gate B** 기존 코드 점검(§6) + 새 코드 테스트 8개.
- **Gate C** 관측 수준 감사(`phase5_observability_information_audit.md`).
- **Gate D** 파일럿: κ = 1, p = 0.7, r = 0의 9 Arm.
  - 버그 2개를 수정했다: A2의 출력 인덱스, lane의 rc 기록.
  - 학습은 안정적이었다: 비유한 0, 상한 도달 0, 42–160초.
  - test 수치는 보지 않았다.
- **Gate E 완료** (12:21): 학습 304개(모두 rc = 0, 비유한 0, 상한 도달 0, 34.9 GPU·h), 평가 36/36, H1 용량 4개, 사전 등록 분석.
- **Gate F 완료** (12:18): Beijing, Jena × p {0.3, 0.7} × seed 3 × (MV, MVshift, SV_k), 102개 rc = 0, 기준선 포함.
- 재실행 명령:
  - `PYTHONPATH=.pydeps:. python experiments/phase5/analyze.py`
  - `python experiments/phase5/analyze_external.py`
  - `python experiments/phase5/analyze_posthoc.py`

**Gate E/F 핵심 결과** (상세: `phase5_controlled_experiment_results.md`)
- **H2 주 대비 B − A (κ = 1, p = 0.7): +0.0137, t-CI [−0.0015, +0.0288], 1/8 → inconclusive. 지지되지 않음.** 점추정은 반대 방향이다.
- κ = 1, p = 0.3: B − A = −0.0128(8/8). 검출되지만 δ = 0.02보다 작다.
- κ = 0 음성 대조: B − A = +0.023(p = 0.7). B가 나쁘다.
- Sham − A = +0.020 ~ +0.029(p = 0.7). **입력 열 추가 자체의 비용**이다.
- 사후 탐색: κ = 1에서 B − Sham = −0.015(8/8), κ = 0에서는 약 0. 결합 정보는 작게 쓰이지만 입력 비용에 가려진다. **확증 아님.**
- L0 층(κ = 1, p = 0.7): B − A = −0.028(8/8). 그러나 RMSE가 약 1.0이라 거의 복원되지 않는다.
- p = 0.3의 L0 층은 표본이 j당 2–3개라 해석할 수 없다.
- H1: raw_joint는 own보다 나쁘다. 폭을 키우면 더 나빠진다(추정량 실패, DPI상 정보는 음수가 아님). → Bayes 수준은 Unresolved.
- H3: y_j 공유 readout은 p = 0.3에서 정확하다(약 0.04). p = 0.7에서는 마스크 간 분산이 약 0.13–0.18이고, s_j의 ridge 복원 오차는 0.44 이상이다. 강한 H3는 기각.
- latent가 raw 특징보다 낫다(전 조건 8/8). DPI상 정보 생성이 아니라 표현 효율이다.
- 학습 seed 변동(약 ±0.01)이 주 효과 크기와 비슷하다.
- **Gate F 사전 기준 충족:** Beijing p = 0.7에서 MV − MV-shift = −0.137, 3/3 seed CI < 0. g가 길수록 이득이 커진다(g ≥ 8에서 −0.386).
  - Jena에서도 모두 음수다.
  - 단일 궤적이다. past-only MV는 미래를 쓰는 선형 보간보다 나쁘다.

**Gate C 주요 결과**
- Γ×Γ는 κ = 1에서 정확한 대칭이다(잔차 0). Γ×Id는 1 시간단위 안에 잔차 30이다.
- z-only 이웃의 49–50%가 y의 부호가 반대다.
- κ = 1 물리 항등식: x_o(t)를 쓰면 y 오차가 0.113 → 0.061이다(과거만 쓰는 2차 차분). 효과 크기 δ = 0.02보다 크다. 즉 **κ = 1의 상대 view 이득은 순간 항등식으로 예상되는 결과다.**
- κ = 1, 자기 창 L0의 y1 국소 증폭은 168이다. 상대 view를 더하면 5.4(MCAR) 또는 0.53(완전)이다.
- κ = 1 궤적마다 부호 점유율이 0.34–0.70으로 크게 다르다. 그래서 test 궤적 10개를 쓴다.

## 5. 알려진 오류와 무효화된 결과

**이전 Phase에서 발견된 문제 (memory와 notes)**
- FPRM 테스트를 다시 돌리지 않은 문제.
- GP plateau.
- P9 오류.
- 이전 held-out ELBO가 조건부 ELBO가 아니었던 문제.
- Phase 3C의 "FDR 일관성 우위"는 관측 좌표에서 나온 것이었다(3D-1).
- future-y 분할 경계 누출(영향 ≤ 2.3e-4).
- Phase 4 view 제거 평가가 OOD였다. **이번 Arm A/B 설계로 대체했다.**

**Phase 5에서 발견된 것**
- A2 출력 인덱스 버그(파일럿에서 발견하고 수정, 회귀 테스트 추가).
- lane rc 기록 버그(수정).

**설계로 해결한 점**
- **모델 선택에 참값을 쓰지 않는다.** val 궤적에서 관측 항목을 가려 기준으로 쓴다. 이전 Phase는 평가 결측 위치의 참값으로 조기 종료했다.

**남은 우려**
- Arm마다 모수 수가 다르다(A 31.5k, B 46.3k, C 57.8k).
- Sham은 κ = 1에서 분포 이동이 있다.
- **입력 열 비용이 B − A를 지배한다**(Sham − A > 0). 이를 보정하는 비교(B − Sham)는 사후 탐색일 뿐이다.
- 조기 종료 기준(val 관측 재구성)은 y_j decoding의 대리 지표가 아니다.

## 6. Gate B — 기존 코드 점검 요약

| 항목 | 결과 |
|---|---|
| 마스크 생성 | 전체 격자 MCAR → 창 절단. 겹치는 창의 일관성 OK [Verified (code)] |
| delay 정렬 | lag k = index k, past-only, 앞쪽 패딩은 미관측으로 처리 [Verified (code), Phase 5 past-only 테스트] |
| 손실 | FDR 다중도 보정 1/c(u)는 기존 tests로 확인. Phase 5에서는 목표 열에만 적용함을 테스트로 확인 |
| 정규화 | train 관측 항목만 사용 [Verified (code)] |
| view 제거 | Phase 4는 OOD였다 → Arm 설계로 대체 |
| 관측/결측 위치 혼합 | Phase 3D-1에서 발견. Phase 5 대치는 결측 위치만, probe는 마스크와 무관한 상태 목표 |
| 분할 경계 | Phase 5는 독립 궤적으로 분리해 경계 문제를 없앴다. 동역학 probe도 같은 궤적 안에서 t + 5만 쓴다 |
| FDR 다중도 가중 | lag-0의 실효 가중이 약 12%다(3D-1). Phase 5 주 지표는 probe라서 lag-0 대치는 부차 지표다 |

## 7. 대기 중인 작업
- 실행 중인 GPU 작업은 없다. 승인됐지만 실행하지 않은 것도 없다.
- **제안 (미승인, 새 사전 등록 필요):**
  1. 새 독립 복제본(train id 8–15)에서 **B − Sham을 주 대비**로 사전 등록해 확증한다.
  2. H1 하한을 구조화 추정량(마스크 패턴별 모델, 물리 항등식 기반)으로 다시 시험한다.
  3. Gate F에 양방향(비 past-only) 변형을 두고, 미래 사용 기준선과 공정하게 비교한다.

## 8. 과학적 해석 (Gate E/F 후)
- **H2: 지지되지 않음**(사전 등록 주 대비 inconclusive, 점추정 반대 방향).
- **H1:** 검출되지 않음(추정량의 한계). Bayes 수준은 Unresolved.
- **H3:** 강한 형태는 기각. 약한 형태(p = 0.3에서 y_j)만 성립.
- **κ = 0 대조:** 정보 0과 일관된다(B ≈ Sham).
- **실제 자료:** 정렬된 multi-view의 예측 이득은 경험적으로 확인됐다. 숨은 상태 복원의 증거는 아니다.
- **지지되지 않는 주장:**
  - 미분동형 대응
  - 전역 식별가능성
  - "잠재가 상태를 발견했다"
  - "multi-view 결합이 coupled 계에서 hidden 상태 복원을 개선한다"(p = 0.7)

## 10. 독립 수학 검증 패키지 (2026-10-28 13:11 생성)
- 위치: `results/review_packages/phase5_20261028/`
  - `phase5_review_documents.zip`: 문서 5개(MF, protocol, results, observability audit, 이 handover의 12:37 버전 = 이 §10 추가 전) + `FILE_INDEX.md`.
  - `phase5_verification_bundle.zip`: 1,016개 파일 + `FILE_INDEX.md` + `MANIFEST.json`(파일별 sha256·크기·mtime·역할·가설).
    - 원본 평가 CSV(eval 144개), 사전 등록/사후/Gate F 분석 결과, H1 용량, Gate C, Gate F npz, 학습 rows/logs/lanes, 분석·학습·평가 코드, 테스트 코드, 의존 모듈 4개.
    - 제외: 궤적 npz 52개와 외부 전처리 npz(해시만 기록), 체크포인트 304개.
  - `SHA256SUMS`, `build_bundle.py`(패키지 생성 스크립트, 읽기 전용 복사만 수행).
- 생성 시 재현 점검(CPU): ZIP만 풀어 `analyze_posthoc.py`, `analyze_external.py` 실행 → 원본 CSV와 바이트 동일. 무결성 테스트 11/11 PASS(원 프로젝트, 13:13).
- 기존 코드·결과·문서는 수정하지 않았다. 새 연구 결론은 작성하지 않았다. GPU는 사용하지 않았다.

**미해결 검토 사항 (외부 검토자에게 확인 요청; 기존 문서에 이미 기록된 항목)**
1. 명제 3(κ = 0 Bayes 이득 0)의 가정: 곱 측도, MCAR, 마스크 독립 — 유한 길이 궤적·공유 test 마스크에서 적용 범위.
2. 명제 2 반례와 H2 판정의 연결: 조건부 의존성 ≠ 위험 감소.
3. κ = 1 SRB 측도의 대칭과 L0 층 부호 식별 여부(MF §8, 미해결).
4. 좌표 관측·encoder의 전역 단사성(국소 rank만 수치 확인).
5. H1: 원시 특징 MLP의 악화가 추정량 실패인지(DPI 논증)와 정보 하한 추정 방법.
6. H2 판정 함수가 TOST를 OPPOSITE보다 먼저 검사하는 순서의 타당성.
7. 사후 탐색 B − Sham, κ DiD(Welch)의 해석 범위 — 확증 아님.
8. Sham의 κ = 1 분포 이동, Arm 간 모수 수 차이(A 31.5k / B 46.3k / C 57.8k).
9. 참값 없는 조기 종료 기준과 y_j decoding의 관계; 학습 seed 변동(약 ±0.01).
10. p = 0.3 L0 층 표본 2–3개(해석 불가)와 층별 다중성 미보정.
11. Gate F: 단일 궤적, seed 3개, 주 블록 bootstrap; MV-shift(14k일)가 계절 정렬도 깨는 점; past-only 대 미래 사용 기준선.

## 9. 다음 세션 지시 (Phase 5 시점 기록. **Phase 6 이후로는 §P6.5–P6.6을 따른다**)
- **현재 상태(13:15 당시):** 독립 수학 검토 대기. 검토 결과가 오기 전에는 새 GPU 학습·추가 실험을 시작하지 않는다(사용자 지시 2026-10-28 13:08).
- **먼저 읽을 파일:**
  1. 이 파일
  2. `phase5_mathematical_foundations.md`
  3. `phase5_hypothesis_protocol.md`
  4. `phase5_observability_information_audit.md`
  5. `phase5_controlled_experiment_results.md`
- **하지 말 것:**
  - 프로토콜을 사후에 바꾸는 것
  - 불리한 복제본을 제외하는 것
  - 원본 자료, 이전 체크포인트, 이전 결과를 수정하는 것
  - 미분동형을 주장하는 것
  - 예약 없이 GPU를 쓰는 것
