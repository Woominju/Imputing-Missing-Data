# FILE_INDEX — phase6_verification_bundle.zip

생성: 2026-10-28 21:16 KST. 프로젝트 루트 `/home/minju/faicpaston/Imputing_Missing_Data`. ZIP 내 경로 = 실제 상대 경로. 원본은 수정하지 않고 복사만 했다.
- 파일별 SHA-256·크기·mtime·역할은 `MANIFEST.json`(files)에 있다.
- 제외한 대용량 파일(궤적 npz, 체크포인트, Oracle Jacobian)은 SHA-256만 `MANIFEST.json`(excluded_hash_only)에 기록했다.
- 이 색인은 위치만 안내한다. 새 결론은 포함하지 않는다.
- 문서 7개는 동반 ZIP `phase6_review_documents.zip`에 있다.

## A. 검토 항목별 근거 위치

**1. L0 조건에서 E[y_j|U_j] = 0의 증명**
- `phase6_g1_protocol.md` §2: 명제 G1.1(생성기 법칙의 Γ×Γ, P 불변), 따름정리 G1.2.
- 인용하는 보조정리 S와 따름정리 3 논증: `results/notes/phase5_mathematical_foundations.md` §2.3.
- 생성기 초기분포: `experiments/phase6/gen6.py:s0_of`. 하위계별 독립 U(−15, 15), U(5, 40).
- 대칭 수치 확인: Phase 5 Gate C `symmetry_check.csv`(Phase 5 검증 ZIP).
- L0 층의 정의(마스크만): `experiments/phase6/g1_info.py`의 `Lc == 0`(자기 x 행 마스크 합).

**2. Δ*의 양의 통계적 하한과 독립 표본 단위**
- 명제 G1.3–G1.4: `phase6_g1_protocol.md` §2. 추론: §4.
- 계산 코드: `experiments/phase6/g1_info.py`
  - `cert_<kind>` = y² − (y − f̄)²
  - f̄ = fold A/B 평균, test와 독립
- 집계: `experiments/phase6/analyze_g1.py`
  - 궤적 단위 cluster bootstrap 10,000회
  - 단측 5% 분위 = LCB
  - overall_lower = p⁸ · LCB
- 원본 합: `results/extra/phase6/g1/k1.0_p0.7.csv`(stratum = L0, quantity = cert_UV / y2 / risk_UV_avg).
  - 단위는 test 궤적 7200–7231(32개 독립)이고, 궤적당 마스크 10개.
- 결과: `results/extra/phase6/g1/analysis_g1.csv`(stratum = L0, quantity = G(UV), bound = lcb).

**3. L0c0에서 현재값이 아닌 지연 정보가 기여한다는 근거**
- 층 정의: `g1_info.py`의 `L0c0 = (Lc == 0) & (cur == 0)`. cur = 상대 x lag-0 마스크.
- 입력 집합: `feats()`
  - UVc = 자기 창 + 상대 lag 0만
  - UV = 자기 창 + 상대 8-lag 창
- 결과: `analysis_g1.csv`(stratum ∈ {L0c0, L0c1}, quantity ∈ {G(UV), G(UVc)}).
- 서술: `phase6_g1_results.md` §1.1, `phase6_final_report.md` Q3.
- c0/c1이 상대 마스크의 함수라는 점과 그에 따른 논증: `phase6_g1_results.md` §1.1 첫 문단.

**4. S1 음성 대조 실패와 S1R 재설계의 전체 기록**
- 사전 규칙: `phase6_g2_g3_protocol.md` §5(음성 대조), §7(보류 규칙).
- 결과: `results/extra/phase6/analysis/g2_contrasts.csv`(kappa = 0, p = 0.7, contrast = 'B - Sham'), `results/extra/phase6/analysis/g2_fixed_sequence.csv`, `results/extra/phase6/analysis/g2_replicate_metric.csv`.
- 원본: `results/extra/phase6/eval/k0.0_p0.7_r*_g2.csv`(24개).
- 사후 진단:
  - 코드: `experiments/phase6/diag/*`. 고정: `results/extra/phase6/diag_k0/FREEZE.txt`.
  - 결과: `results/extra/phase6/diag_k0/diag_summary.csv`, `eval_J/`, `eval_S/`.
  - 서술: `phase6_g2_g3_results.md` §5, §5.1.
- S1R:
  - 사전 등록: `phase6_g2_g3_protocol.md` §9–§10. 고정과 수정 기록: `results/extra/phase6/s1r/FREEZE.txt`.
  - 코드: `experiments/phase6/s1r/*`.
  - 원본: `results/extra/phase6/s1r/eval/`. 결과: `s1r_results.csv`.
  - 첫 실행 실패 로그: `results/extra/phase6/s1r/lanes/failed_syntax_2009/`.
  - 서술: `phase6_g2_g3_results.md` §6.

**5. Sham donor의 독립성과 κ = 0 음성 대조의 정확한 가정**
- 가정과 증명: `phase6_mathematical_errata.md` E3(명제 E3.1, 가정 (i)–(iv)), E4, E6.
- Phase 5 donor 지도: `results/extra/phase6/g0/phase5_sham_donor_map.csv`. 의존성 감도: `results/extra/phase6/g0/phase5_bsham_dependence.csv`.
- Phase 6 donor 선택: `experiments/phase6/core6.py:ids`, `build`
  - 복제본마다 train/val/test donor가 독립
  - 고정 정규화 하나
- 진단과 S1R의 donor: `diag/k0_common.py:ids`, `s1r/common.py:ids`.
- 테스트: `experiments/phase6/tests/test_phase6.py`
  - `t_roles_never_reused_across_replicates`
  - `t_masks_identical_across_arms_and_sham_columns`
  - `t_seeds_disjoint_from_phase5_and_unique`

**6. H3 6차원 공유 상태 복원 실패의 정확한 실험 조건**
- 사양: `phase6_g2_g3_protocol.md` §6(readout, 특징 집합, 층, 사전 기준 (a)–(c)).
- 코드: `experiments/phase6/evaluate6.py`
  - G3_FEATS
  - `mlp_fit(..., width = 128)`, 6-D target = 정규화 상태
  - 마스크 e = 0..4
  - `joint_lab`, `sig_min`
- Oracle Jacobian: `experiments/phase6/jac6.py`.
- AE 학습 목표(자기 view만 복원): `core6.py:arm_spec`의 outs, `experiments/fdr/loss.py`, `train6.py`(손실은 목표 열에만).
- 결과: `results/extra/phase6/analysis/g3_criteria.csv`(approx_state_recovery), `g3_accuracy_per_rep.csv`, `g3_stability_per_rep.csv`, `g3_signerr_per_rep.csv`.
- 서술: `phase6_g2_g3_results.md` §3–§4.

**7. 사전 등록 분석과 사후 탐색 분석의 구분**
- 표: `phase6_final_report.md` "사전 등록 결과와 사후 탐색의 구분".
- 고정 시각과 해시:
  - `results/extra/phase6/PROTOCOL_FREEZE_g1.txt`
  - `results/extra/phase6/PROTOCOL_FREEZE_g2g3.txt`(분석 스크립트 고정 줄 포함)
  - `results/extra/phase6/diag_k0/FREEZE.txt`(사후)
  - `results/extra/phase6/s1r/FREEZE.txt`(S1R)
- 사후 코드는 `experiments/phase6/diag/`에 분리했다. 사후 결과는 `results/extra/phase6/diag_k0/`, 메타는 `results/extra/phase6/s1r/meta_g2S1_plus_s1r.csv`에 있다.

## B. 실험별 설정 Manifest (요약; 정확한 값은 코드와 rows CSV의 cfg / mask_seeds 열)

| 실험 | 코드 | 설정 | 출력 |
|---|---|---|---|
| G0 | `g0_checks.py` | CPU, Phase 5 자료 읽기 전용 | `g0/` |
| G1 | `g1_info.py` | κ ∈ {0, 1} × p ∈ {0, 0.3, 0.7}; MLP 3 × 256, fold A/B 각 16 궤적, val 8, test 32 × 마스크 10 | `g1/` |
| G2/G3 | `gen6.py`, `core6.py`, `train6.py`, `evaluate6.py` | κ 2 × p 2 × 복제본 24 × Arm 10 = 960; CFG = Phase 5와 같음(rows `cfg` 열); init seed 6000 + r | `eval/`, `analysis/`, `runs/` |
| 사후 진단 | `diag/` | κ = 0, p = 0.7, 복제본 24 × {J, S} × {B1, B2, Sham1, Sham2} = 192 | `diag_k0/` |
| S1R | `s1r/` | κ ∈ {1, 0}, p = 0.7, 복제본 24 × {B1, B2, Sham1, Sham2} = 192 | `s1r/` |

**제외 파일 (SHA-256은 MANIFEST.json)**
- G2/G1 궤적(1,256): 1256개, 452.0 MB
- 진단 궤적 J: 480개, 144.3 MB
- 진단 궤적 S: 480개, 143.6 MB
- S1R 궤적: 960개, 288.4 MB
- G2 체크포인트: 960개, 173.3 MB
- 진단 체크포인트 J: 96개, 18.5 MB
- 진단 체크포인트 S: 96개, 18.5 MB
- S1R 체크포인트: 192개, 36.9 MB
- Oracle Jacobian (jac6.py로 재생성 가능): 48개, 194.7 MB

## C. 무결성 테스트
- `experiments/phase6/tests/test_phase6.py`: 9개
- `experiments/phase5/tests/test_phase5.py`: 8개
- `experiments/phase5/tests/test_external.py`: 3개
- 패키지 생성 시 원 프로젝트에서 재실행한 결과는 아래 §E에 적는다.

## D. 파일 목록 (그룹별 개수)
- code: 12개
- test: 2개
- code-posthoc: 7개
- code-S1R: 8개
- code-dep: 12개
- ref-doc: 3개
- freeze: 4개
- G0: 3개
- G1-raw: 18개
- G1-analysis: 1개
- G2-raw: 96개
- G3-raw: 192개
- G2-run: 2065개
- G2G3-analysis: 9개
- G3-run: 1개
- data: 1개
- diag: 482개
- S1R: 507개

## E. 패키지 생성 시 점검
점검 시각: 2026-10-28 21:15–21:17 KST. GPU는 사용하지 않았다(점검 시 두 GPU 0 MiB). 새 학습도 하지 않았다.

**1. 무결성 테스트 (원 프로젝트에서 실행)**
- `test_phase6.py` 9/9 PASS
- `test_phase5.py` 8/8 PASS
- `test_external.py` 3/3 PASS
- 이 테스트들은 궤적 npz가 필요하므로 ZIP만으로는 실행할 수 없다(npz는 해시만 포함).

**2. ZIP만으로 재현한 분석 (CPU, `python -I`)**
- 이 번들만 풀어서 `analyze_g1.py`, `analyze6.py`, `s1r/analyze.py`를 실행했다.
- 다음 출력이 원본과 **바이트 단위로 같다**:
  - `g1/analysis_g1.csv`
  - `analysis/g2_contrasts.csv`
  - `analysis/g2_did.csv`
  - `analysis/g2_fixed_sequence.csv`
  - `analysis/g2_replicate_metric.csv`
  - `analysis/g3_criteria.csv`
  - `analysis/g3_accuracy_per_rep.csv`
  - `s1r/s1r_results.csv`

**3. MANIFEST 대조**
- 포함 파일 3,423개의 SHA-256이 ZIP 추출본·원본과 모두 일치한다.
- 제외 파일 4,568개는 표본 23개를 다시 계산했고, 모두 일치한다.
