# phase7_review_documents — FILE_INDEX

Built 2026-10-29 09:05 KST from /home/minju/faicpaston/Imputing_Missing_Data (paths relative to it).
SHA-256 of every file: SHA256SUMS.txt (verify: `sha256sum -c SHA256SUMS.txt` after unzip).


## Phase 7 pre-registration protocol (P7-B) and freeze record (2 files)

- `results/extra/phase7/PROTOCOL_FREEZE_p7b.txt` (1,223 B)
- `results/notes/phase7_p7b_protocol.md` (7,284 B)

## Phase 7 mathematical corrections (P7-A) (1 files)

- `results/notes/phase7_mathematical_corrections.md` (13,625 B)

## Phase 7 final report (1 files)

- `results/notes/phase7_final_report.md` (31,707 B)

## Latest research handover (1 files)

- `research_handover_latest.md` (41,612 B)
