# phase8_final_review_20261029 — FILE_INDEX

Built 2026-10-29 10:47 KST (server clock) from /home/minju/faicpaston/Imputing_Missing_Data; paths are relative to it.
Purpose: final independent review of the Phase 8 v2 protocol and code BEFORE Gate C (hash freeze). Nothing in this package has been frozen;
no Phase 8 data, training, oracle, evaluation or analysis output exists yet (results/extra/phase8 does not exist).
Verify after unzip: `sha256sum -c SHA256SUMS.txt`. Run tests: `PYTHONPATH=.pydeps:. python experiments/phase8/tests/test_phase8.py` (needs Phase 6 pool data + Phase 7 data/ckpts present on the server).


## A. Protocol and review documents

| file | role | bytes | SHA-256 |
|---|---|---|---|
| `results/notes/phase8_mathematical_protocol_v2.md` | Phase 8 protocol v2 (UNFROZEN): definitions, propositions with proofs, design, primary outcomes, decision rules | 52,011 | `02528b2ff670f791d4dd6a7b56b07350c5d540f889e30ab6cc313ab43af07b09` |
| `results/notes/phase8_revision_crosswalk.md` | v1 -> v2 crosswalk: ChatGPT items 1-12 + self-review R1-R6 -> v2 sections | 6,214 | `9e53226c5cf17205b73bd14f4f7e0aa6a1b9835aac0c5c29445b80b8e2d7e550` |
| `results/notes/phase8_gateB_integrity.md` | Gate B integrity report: finalized items, code<->protocol map, defects fixed, residual risks | 9,236 | `6d947d8e9642950135c739d3f5aa156cee2be749f8ddf826cbfbe81c233ca2b7` |
| `results/notes/phase8_final_precheck.md` | Final mathematical/experimental pre-check (9 items) + findings F1-F8 applied before freeze | 9,758 | `b3d7b667ef075ef5c78fd93f01e6cbb7bf114eec015d173e69fa8c2a7bac3636` |
| `results/notes/phase8_gateB_test_log.txt` | Gate B CPU test log (18/18 PASS, original Gate B record) | 787 | `d2780c2ac63c09db1a25ca8035856596ed4b6d8061d88f68c19ba8b99fc4d00f` |
| `results/notes/phase8_gateB_test_log_v2.txt` | CPU test log on the CURRENT code (20/20 PASS; includes scheduler/atomicity/incomplete-cell tests) | 883 | `d699e8cee5f9ecd9351e061fe206849ecb493491e5564259cb5c1d2d53363310` |
| `results/notes/phase8_mathematical_protocol.md` | v1 draft (446 lines, unchanged) - reference for the crosswalk | 35,123 | `c5e37088bdeb485380b246f3346f55b24ba8c8e326b88d09f47e1b7cac1e1eea` |
| `results/notes/phase8_protocol_review_notes.md` | Self-review R1-R6 of v1 (line-referenced) | 22,912 | `559cb30b01b0a4219354534441b3fe610db822db790ce98fd0b3d704d467b086` |
| `research_handover_latest.md` | Latest research handover (entry point section P8; Phase 5-7 records preserved) | 57,687 | `f9b9f7d6d9b5b856a6681fb09f5007eefe50f93b4839515303f1b3fd8f3aecef` |

## B. Phase 8 execution / analysis / test code

| file | role | bytes | SHA-256 |
|---|---|---|---|
| `experiments/phase8/core8.py` | constants (CONST, FULL/SMALL sizes), ids/seeds, masks, arm specs, data assembly, strata, sym0, R1 readout rule | 12,085 | `b84cc1a30c90bc8fe785d412667eaa35fd521afb145045dca2eae9ca0087e1e4` |
| `experiments/phase8/gen8.py` | data generation: replicate/donor/pool trajectories + i.i.d. kNN reference (one point per independent trajectory) | 2,099 | `c22c040f4009a1224f5db571f5d3c73882edf5cbf92ca1e9c83e99cfc44a35fe` |
| `experiments/phase8/train8.py` | AE training of one arm (Phase 7 loop unchanged; arm table from core8) | 4,901 | `d9e3f4b58d97573fb378605987a21fab24ef2a665f2e8ad739e1a6012ad5a8c9` |
| `experiments/phase8/feats8.py` | feature sets (Bfull, BfullSham_j, Fact8, Fact8Sham_j, Fact16, raw_joint) from canonical 4-view arrays | 2,790 | `f5ecda8408f64565007dc265dc3e4b6474e7b861c3ad9177deeb0f1b339c17a6` |
| `experiments/phase8/oracle8.py` | supervised diagnostic oracles O_raw, O_own_j, O_imp, O_lat, saturation (pool only; width on pool-val) | 7,142 | `7dec0bbfa7fa70c37f73ed14bf048d3227984a97353a6522af73a1471ce45e1e` |
| `experiments/phase8/knn8.py` | D5a kNN oracle upper bound (+ O_raw on same points) and D5b 1/2*1-NN statistic (exploratory) | 6,997 | `ba8b6d0f4f932190d4b0d39ede991f3a251b0fe5b4088585adac73f51a6462f2` |
| `experiments/phase8/evaluate8.py` | per-replicate evaluation: acc/pair/imp/lat additive sums for Families I-IV | 8,929 | `c22a6974ef6a1ab06ff1a14bbf2fdf71ccaaff7221b9d4dc5ceed9312741e914` |
| `experiments/phase8/eval_p7imp8.py` | Family III on existing Phase 7 checkpoints (missing-position imputation) | 2,882 | `6f0ebcf5acf0ffc3a60100c3bbf702fb768c128e739c969d36fdf29c37baccfb` |
| `experiments/phase8/analyze8.py` | pre-registered analysis: Family I sequence, T_A/LB, gates (sign + TOST), IIa/IIb sequences, GSR descriptive, III, IV | 16,662 | `f123ff0c0436ec1bf13e7c8ff8b9d043759d8e460950ee7baa3dedd719d359d9` |
| `experiments/phase8/sched8.py` | evidence-based scheduler: p=0.7 priority, DEADLINE/HARD_DEADLINE guards, GPU alternation | 7,158 | `c3af2ab8642e68eba76c16f1e5ed3734eaa9af7fbd851b9399542f7c4e5db539` |
| `experiments/phase8/launch_p8.sh` | Gate D launcher: verifies freeze hashes + labres-check, sets deadlines, setsid detach (NOT run) | 2,623 | `2ca2a16c9f459ab628ff82550c3c5d16e4905e66ee3ba71d67d6aa409dcf126c` |
| `experiments/phase8/tests/test_phase8.py` | 20 CPU integrity tests incl. end-to-end smoke | 22,659 | `272c3bfce2545881d8fc801aea3ff71fa217aede0a5cbd0c00feac9e71845f8b` |
| `experiments/phase8/__init__.py` | package marker | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `experiments/phase8/tests/__init__.py` | package marker | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

## C. Phase 5-7 dependencies actually imported (unmodified)

| file | role | bytes | SHA-256 |
|---|---|---|---|
| `experiments/phase5/core.py` | ArmModel (FDR-Learned), encode_series, raw_features, seed_of, mcar, OBS/SUB/SPAN | 6,497 | `c4e40997a51927c080f7ccc49ce1b2f990d1ee9268c8993834ffb927162889a6` |
| `experiments/phase5/evaluate.py` | imported by phase6/evaluate6 (test of R1 rule only) | 11,837 | `75540211b57ad896f66cc0e1a63f41d1105e3f5b9fa837a6e20e6857bde05c57` |
| `experiments/phase6/core6.py` | fixed normalisation constants norm_stats (Phase 6 pool 900-903) | 4,093 | `5cdbce95daadfa620c3b5cd3f644d754dbe7c4a279f6185ee00ba43ddf6a13e9` |
| `experiments/phase6/gen6.py` | seed rule s0_of, SEED6, Phase 6 roles (seed-disjointness test) | 2,675 | `b72db51946b09560ea47008b7185acfc7f79d724cffe974c7b60614ff201179d` |
| `experiments/phase6/evaluate6.py` | reference R1 readout mlp_fit (bit-equality test) | 12,121 | `7fadad47ad32e9230b35d66f675f67589e489a5dd6ab6e3400e9458c1143cd79` |
| `experiments/phase6/diag/k0_common.py` | Phase 6 diagnostic ids (seed-disjointness test) | 1,796 | `e4d7f486991a2f3a5730a16f6c77169462025f98f293e969b15963ee5adcc4ce` |
| `experiments/phase6/s1r/common.py` | Phase 6 S1R ids (seed-disjointness test) | 988 | `d2daf2a72123b0ed75358f0c33cd7272e206ea902d437961541b05a59387b82a` |
| `experiments/phase7/core7.py` | Phase 7 data/ids/checkpoint access for eval_p7imp8 and seed-disjointness test | 3,216 | `9231c280c8fa7e251b0839d27d199a8b066bcde92d112c022453de288db38fca` |
| `experiments/fdr/loss.py` | FDR masked loss (unchanged) | 3,716 | `37cac2543bde34e402785a11cd5d17f2b16cef508cf4bdbe89775bcc18e3d2f9` |
| `src/delay_embedding.py` | delay_embed / pad_front | 1,094 | `aa1e97a14fcef78c69f68b711477d2dc237dbb14d556bee485eb35b8a0e283e1` |
| `src/models.py` | group_mlp / mlp building blocks | 4,891 | `fc6b8b6318c8ecbc1572f12db31c1fe365ef56763569d6216e1e525180e784fe` |
| `src/lorenz.py` | coupled Lorenz generator (vector field, DOP853 integration) | 2,105 | `8b8adcf032c32a183db83bf40f388c35a359adf28b183b20b07b9e812dc0bdb9` |
| `results/extra/phase7/PROTOCOL_FREEZE_p7b.txt` | Phase 7 freeze record (test: earlier phases untouched) | 1,223 | `4e4421e0c7df67f6c5857c78d4efdd7ca56bfad8728bea46972403d940cf1b3a` |
