#!/bin/bash
# Phase 8 Gate D launcher (prepared before freeze; run ONLY after Gate C and explicit user approval).
# usage: experiments/phase8/launch_p8.sh "YYYY-MM-DD HH:MM"   (= GPU reservation END as shown by labres-check)  [NPAR]
# Refuses to start unless: (1) results/extra/phase8/PROTOCOL_FREEZE_p8.txt exists and every hash in it verifies;
# (2) labres-check shows the stated end time for this user's GPU 0 and 1 and no warning. Deadlines are derived from the END:
#   DEADLINE_EPOCH = END - 35 min (no new task; longest single task ~ 25 min), HARD_DEADLINE_EPOCH = END - 5 min (terminate).
# Detached with setsid/nohup so an SSH disconnect cannot kill the run; afterwards analyze8 runs once on whatever finished
# (incomplete cells are reported as 미실행 / inconclusive by analyze8).
set -u
cd /home/minju/faicpaston/Imputing_Missing_Data
END="${1:?reservation end 'YYYY-MM-DD HH:MM'}"; NPAR="${2:-24}"; PY=/home/minju/.conda/envs/reef_gpu/bin/python
FZ=results/extra/phase8/PROTOCOL_FREEZE_p8.txt
[ -f "$FZ" ] || { echo "REFUSED: no freeze file $FZ (Gate C not done)"; exit 2; }
grep -E '^[0-9a-f]{64}  ' "$FZ" | sha256sum -c --quiet || { echo "REFUSED: freeze hashes do not verify"; exit 2; }
LC=$(labres-check 2>&1); echo "$LC"
HM=$(date -d "$END" +%H:%M) || exit 2
echo "$LC" | grep -q "GPU 0 .*~$HM\|GPU 0 · [0-9:]*~$HM" || { echo "REFUSED: labres-check does not show GPU 0 reserved until $HM"; exit 2; }
echo "$LC" | grep -q "GPU 1 .*~$HM\|GPU 1 · [0-9:]*~$HM" || { echo "REFUSED: labres-check does not show GPU 1 reserved until $HM"; exit 2; }
echo "$LC" | grep -q "GPU 예약 경고" && { echo "REFUSED: [GPU 예약 경고] present"; exit 2; }
E=$(date -d "$END" +%s); DL=$((E - 35 * 60)); HD=$((E - 5 * 60)); NOW=$(date +%s)
[ "$NOW" -lt "$DL" ] || { echo "REFUSED: too close to reservation end"; exit 2; }
mkdir -p results/extra/phase8/logs
echo "launch $(date '+%F %T') END=$END DEADLINE=$(date -d @$DL '+%T') HARD=$(date -d @$HD '+%T') NPAR=$NPAR" | tee -a results/extra/phase8/logs/launch.log
setsid nohup bash -c "
  export PYTHONPATH=.pydeps:. CUDA_DEVICE_ORDER=PCI_BUS_ID GPUS=0,1 DEADLINE_EPOCH=$DL HARD_DEADLINE_EPOCH=$HD
  $PY experiments/phase8/gen8.py 60 >> results/extra/phase8/logs/gen8.log 2>&1 || exit 3
  $PY experiments/phase8/sched8.py $NPAR >> results/extra/phase8/logs/sched8.stdout 2>&1
  [ -f results/extra/phase8/analysis/p8_summary.txt ] || $PY experiments/phase8/analyze8.py >> results/extra/phase8/logs/analyze8_final.log 2>&1
  echo \"[\$(date '+%F %T')] PIPELINE END\" >> results/extra/phase8/logs/launch.log
" > /dev/null 2>&1 < /dev/null &
echo "started detached pid $!"
