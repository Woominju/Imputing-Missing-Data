"""Phase 8 evidence-based scheduler (Gate D only; protocol v2 section 11). A task starts only when all its dependency FILES exist and its
output file does not; failed tasks (rc != 0) are logged and never retried automatically (their dependants then never start).
Every task writes its output marker LAST and atomically (tmp + rename), so a killed task never leaves a marker.
Reservation guards (orchestration only; no effect on any estimand):
  DEADLINE_EPOCH       (unix s) no new task starts at or after this time;
  HARD_DEADLINE_EPOCH  (unix s) every running task is terminated (SIGTERM, then SIGKILL after 30 s) and the scheduler exits;
                       must be set BEFORE the GPU reservation ends. Terminated tasks are logged as 'killed' and count as not run.
Priority (protocol v2 section 11): all confirmatory analyses are at p = 0.7 -> the whole p = 0.7 pipeline (oracles, AE training,
O_lat, kNN, evaluation) is listed before p = 0.3; within a p, downstream tasks are listed before the next p's training so that
they take free slots as soon as their dependencies exist. P7 imputation and analysis come last.
GPUs from env GPUS (default "0,1"), CUDA_DEVICE_ORDER=PCI_BUS_ID; P8_SMOKE=1 forces CPU.
usage: sched8.py NPAR [--dry]"""
import os, signal, subprocess, sys, time
from experiments.phase8.core8 import ROOT, RUNS, ORC, EVAL, ANA, DDIR, SZ, CONST, ARMS8, init_seed
from experiments.phase8.oracle8 import opath

PY = sys.executable; P_ORDER = (0.7, 0.3)


def row(k, p, r, arm):
    return f"{RUNS}/rows/k{k}_p{p}_r{r}_{arm}_s{init_seed(arm, r)}.csv"


def tasks():
    """list order = preference among READY tasks: for each p (0.7 first): oracles, then downstream (sat, kNN, O_lat, eval), then
    AE training. Downstream tasks are not ready until their dependency files exist, so training proceeds first, but every
    downstream task takes a free slot as soon as it becomes ready (before any further training)."""
    T = []; R = range(SZ["R"])
    for p in P_ORDER:
        KP = [k for k in CONST["kappas"]]; orc, down, train = [], [], []
        for k in KP:
            for kind in ("raw", "own1", "own2", "imp"):
                orc.append((f"orc:{kind}:{k}:{p}", ["experiments/phase8/oracle8.py", kind, "--kappa", str(k), "--p", str(p)], [], opath(kind, k, p)))
            ref = f"{DDIR}/ref_k{float(k)}.npz"
            down.append((f"orc:sat:{k}:{p}", ["experiments/phase8/oracle8.py", "sat", "--kappa", str(k), "--p", str(p)], [opath("raw", k, p)], f"{ORC}/sat_k{float(k)}_p{p}.json"))
            down.append((f"knn:eval:{k}:{p}", ["experiments/phase8/knn8.py", "eval", "--kappa", str(k), "--p", str(p)], [opath("raw", k, p), ref], f"{EVAL}/knn_k{float(k)}_p{p}.csv"))
            down.append((f"knn:d5b:{k}:{p}", ["experiments/phase8/knn8.py", "d5b", "--kappa", str(k), "--p", str(p)], [ref], f"{EVAL}/d5b_k{float(k)}_p{p}.csv"))
        for r in R:                                      # replicate-major: complete replicates appear early
            for k in KP:
                for feat, arms in (("Bfull", ["Bfull"]), ("Fact8", ["A1_8", "A2_8"])):
                    down.append((f"orc:lat:{k}:{p}:{r}:{feat}", ["experiments/phase8/oracle8.py", "lat", "--kappa", str(k), "--p", str(p), "--rep", str(r), "--feat", feat],
                                 [opath("raw", k, p)] + [row(k, p, r, a) for a in arms], opath("lat", k, p, r, feat)))
                deps = [row(k, p, r, a) for a in ARMS8] + [opath(x, k, p) for x in ("raw", "own1", "own2", "imp")] + [opath("lat", k, p, r, f) for f in ("Bfull", "Fact8")]
                down.append((f"eval:{k}:{p}:{r}", ["experiments/phase8/evaluate8.py", "--kappa", str(k), "--p", str(p), "--rep", str(r)], deps, f"{EVAL}/k{k}_p{p}_r{r}_acc.csv.gz"))
                for arm in ARMS8:
                    train.append((f"train:{k}:{p}:{r}:{arm}", ["experiments/phase8/train8.py", "--kappa", str(k), "--p", str(p), "--rep", str(r), "--arm", arm], [], row(k, p, r, arm)))
        T += orc + down + train
    for p in P_ORDER:
        for k in CONST["kappas"]:
            for r in range(24 if not os.environ.get("P8_SMOKE") else 0):
                T.append((f"p7imp:{k}:{p}:{r}", ["experiments/phase8/eval_p7imp8.py", "--kappa", str(k), "--p", str(p), "--rep", str(r)], [], f"{EVAL}/p7imp_k{k}_p{p}_r{r}.csv.gz"))
    T.append(("analyze", ["experiments/phase8/analyze8.py"], [t[3] for t in T], f"{ANA}/p8_summary.txt"))
    return T


def main():
    npar = int(sys.argv[1]); dry = "--dry" in sys.argv; smoke = os.environ.get("P8_SMOKE") == "1"
    gpus = [""] if smoke else os.environ.get("GPUS", "0,1").split(",")
    dl = float(os.environ.get("DEADLINE_EPOCH", "inf")); hard = float(os.environ.get("HARD_DEADLINE_EPOCH", "inf"))
    T = tasks()
    if dry:                                                   # no side effects
        print(len(T), "tasks"); [print(n, "|", " ".join(c), "| deps", len(d), "| out", o) for n, c, d, o in T]; return
    if not smoke and (dl == float("inf") or hard == float("inf") or hard <= dl):
        sys.exit("REFUSED: real runs need DEADLINE_EPOCH < HARD_DEADLINE_EPOCH (both before the GPU reservation end)")
    os.makedirs(f"{ROOT}/logs", exist_ok=True); LOG = open(f"{ROOT}/logs/sched8.log", "a")
    log = lambda s: (LOG.write(f"[{time.strftime('%m-%d %H:%M:%S')}] {s}\n"), LOG.flush())
    env = dict(os.environ, PYTHONPATH=".pydeps:.", CUDA_DEVICE_ORDER="PCI_BUS_ID", OMP_NUM_THREADS="2"); running, failed, gi = {}, set(), 0
    log(f"START {len(T)} tasks npar={npar} gpus={gpus} deadline={dl} hard={hard}")
    while True:
        for nm, (pr, fh) in list(running.items()):
            if pr.poll() is not None:
                fh.close(); del running[nm]; log(f"end {nm} rc={pr.returncode}")
                if pr.returncode != 0:
                    failed.add(nm)
        if time.time() >= hard:
            for nm, (pr, fh) in running.items():
                pr.send_signal(signal.SIGTERM); log(f"killed {nm} (hard deadline)")
            t0 = time.time()
            while any(pr.poll() is None for pr, _ in running.values()) and time.time() - t0 < 30:
                time.sleep(1)
            for nm, (pr, fh) in running.items():
                if pr.poll() is None:
                    pr.kill()
                fh.close()
            log(f"EXIT hard deadline; killed={sorted(running)} failed={sorted(failed)}"); break
        todo = [t for t in T if t[0] not in running and t[0] not in failed and not os.path.exists(t[3])]
        ready = [t for t in todo if all(os.path.exists(d) for d in t[2])]
        if time.time() < dl:
            for nm, cmd, _, _ in ready[:max(0, npar - len(running))]:
                g = gpus[gi % len(gpus)]; gi += 1; fh = open(f"{ROOT}/logs/{nm.replace(':', '_')}.log", "w")
                running[nm] = (subprocess.Popen([PY] + cmd, stdout=fh, stderr=subprocess.STDOUT, env=dict(env, CUDA_VISIBLE_DEVICES=g)), fh); log(f"start {nm} gpu {g}")
        if not running and (not ready or time.time() >= dl):
            log(f"EXIT todo={len(todo)} failed={sorted(failed)} deadline_passed={time.time() >= dl}"); break
        time.sleep(1 if smoke else 20)


if __name__ == "__main__":
    main()
