# Research Handover — LATEST

**갱신 시각:** 2026-10-31 19:10 KST(서버 시계).

**현재 단계:** **Phase 8 완료. 사후 독립 감사 완료, ChatGPT 재감사 대기.**
- Gate D: 1,276/1,276 완료(18:19:44), 실패 0, 무효 AE 실행 0
- complete 분석: `results/extra/phase8/analysis/complete_20261031-181946_0f246de749/`
- 독립 감사: 원자료 재계산 54/54 일치
- **진입점은 §P8.Z다.** Phase 9는 시작하지 않았다(사용자 승인 필요).

**운영 원칙**
- 이 파일이 다음 세션(Claude Code / ChatGPT)의 진입점이다.
- 이정표마다 스냅샷을 `results/notes/handover_snapshots/`에 남긴다. 이번 갱신 전 스냅샷은 `handover_20261031_actual1905_before_phase8_audit.md`(SHA-256 `ed2e8063…c6d2`)다.
- 이전 음성 결과와 미해결 이의는 지우지 않는다.

## P8.Z Phase 8 완료와 사후 독립 감사 (2026-10-31)

### P8.Z.1 실행 완료
- **경과**
  - 10-29 11:17 시작
  - 13:19 서버 GPU 설치로 계획 중지(432/1276)
  - 10-31 16:23 재개(GPU 0, 1)
  - 16:26 GPU 0–3으로 재시작(NPAR 32)
  - 18:19:44 `EXIT todo=0 failed=[]`
  - 18:19:58 analyze8가 complete 판본을 작성
- **환경 변경(실행 전용):** 기록은 `results/extra/phase8/FREEZE_CHANGES.md`에 있다.
  - NVIDIA 드라이버 580.105.08 → 580.196.07
  - L40S 2대 → 4대
  - `launch_p8.sh` 2회 변경: `P8_GPUS`, 날짜가 붙은 예약 종료 형식 처리
  - 고정 목록의 해시 2줄 갱신. 옛 해시는 주석으로 보존했다.
  - **나머지 810개 고정 대상은 Gate C와 같다.**
  - Gate C 원본 3개 파일을 바이트 단위로 보존했고 diff를 남겼다: `results/audit/phase8_postrun_20261031/freeze_evidence/`
- **실행 무결성 (감사 E1–E5)**
  - 출력 1,276개 존재, 중복 완료 0, 실패·임시 파일 0, checkpoint 864
  - 궤적 1,056개가 모두 서로 다르다. test와 정확히 같은 상태를 공유하는 점이 풀, 참조, train, donor 어디에도 0개다.
  - `eval:0.0:0.7:17`은 완료 로그가 없다. SIGTERM 직전에 완성됐고, 출력을 검증해 유효하다.

### P8.Z.2 확증 결과 (원자료 독립 재계산으로 재확인)

| 단계 | 판정 | 값 |
|---|---|---|
| I-1 κ=1, p=0.7, H, G_tot > δ_I | **PASS** | 0.04412, 97.5% LCB 0.04117 |
| I-2 G_lat > δ_I | **FAIL** (δ 근방 무차별) | 0.01898 [LCB 0.01746, UCB 0.02050] |
| I-3, I-4 (κ=0) | 미검정(고정 순서) | 서술: 0.0542, 0.0270 |
| 게이트 IIa, IIb (κ=0, p=0.7) | **PASS / PASS** | TOST 90% CI ⊂ ±0.01, ε/SD 1.96 / 1.79 |
| IIa-1 CG_Bfull < 0 | **PASS**, **δ_y = 0.02 미달** | −0.00863 [UCB −0.00548], 21/24 |
| IIa-2 C_Bfull > 0 (P8.4b 인증) | **PASS** | 0.03337 [LCB 0.02447], 24/24 |
| IIb-1 Δ_JF < 0 | **미검출(경계)** | −0.00278 [UCB +0.0000286] |
| IIb-2 | 미검정 | 서술: RMSE_s6(Bfull) − RMSE_s6(Fact8) = **+0.0176**(B-full이 나쁨) |

### P8.Z.3 부정적 결과 (보존)
1. 결합 인코더의 병치 대비 우위(IIb-1)는 확증되지 않았다.
   - 혼합 드라이버 복제본 2개를 빼면 검출로 바뀌는 **경계 결과**다(사후, 판정 불변).
2. B-full은 6차원 상태 decodability에서 Fact8(+0.018)과 Fact16(+0.025)보다 나쁘다. κ=0에서도 그렇다(서술).
3. **대치(Family III, 서술)**
   - p=0.7에서는 두 κ 모두 Fact8/Fact16이 B-full보다 낫다(κ=1: 0.296 대 0.312).
   - B-full이 나은 곳은 κ=1, p=0.3 전체와 κ=1의 자기 x 미관측(L_j0) x 대치뿐이다.
   - 지도 O_imp(0.260)에 못 미친다. FPRM과의 비교는 없다.
4. **GSR 서술 기준:** (b), (c) 미충족이다.
   - (d)(ρ_φ Bfull < Fact8)는 κ=0에서도 같은 크기다.
   - readout 수준의 마스크 분산은 반대 방향이다(B-full이 더 큼).
   - 잠재 근방 보존에서 B-full 우위가 없다.
5. **IIa-1의 크기는 δ_y의 43%다.** 병치 파이프라인도 같은 결합 이득을 실현한다(CG_Fact8 −0.0059 24/24, C_Fact8 0.035).
6. **O_raw는 포화되지 않았다.** κ=0에서 자기 창만 보는 O_own이 O_raw를 이긴다(y_j −0.015). 따라서 R*_H의 위치는 미지다.
7. Phase 6 G2 κ=0 대조 실패의 원인은 여전히 Unresolved다.

### P8.Z.4 증명된 수학적 명제 (Verified (math); 구현이 전제를 만족함을 감사로 확인)
- **프로토콜 v2의 명제:** L1(대칭군), L2(포획, 흐름의 미분동형), L3(P ≠ ν), B1/D4, B3, N1-X0, N1-L_j0(κ=0), N1-own, P8.1–P8.4, 명제 2.2, §2.3, C1–C5
- **Phase 8 자료로 인증된 진술(통계 LCB 조건부)**
  - (T1) H층 모델 한계 ≥ 0.041 MSE
  - (T2) κ=1 L_j0에서 φ_Bfull(W)는 W_j의 a.s. 함수가 아니다.
  - (T3) X0에서 B-full 위험의 ≥ 83%는 정보 한계다(LB_X0 = 0.6679이며 2/3이 아니다).
  - (T4) κ=0 L_j0에서 ≥ 72%는 정보 한계다.

### P8.Z.5 미해결 수학 문제
- H∖X0(H의 95%)의 정량적 하한
- R*_H의 위치
- G_tot 원인 분해(인코더, readout, 부류, 자료량, 최적화)
- 모든 층의 P- 또는 ν-식별가능성
- 연속 인코더의 차원 병목
- D5b의 일관성 조건(p=0.3 X0에서 증명된 LB보다 작게 나옴)
- IIb의 (i)/(ii) 구별
- ρ_φ와 상태 공간 안정성의 불일치
- 학습된 사상의 국소 immersion, 전역 단사, 안정 역, 미분동형 대응

### P8.Z.6 Official AIM 정합성
- **확립된 조각:** "불완전한 상대 view에 결합 특이 정보가 있고, 현재 파이프라인이 그 일부를 쓴다"(Empirical + P8.4 인증)
- **미확립**
  - 결합 공유 잠재가 병치보다 통합을 잘한다(Unresolved, 서술은 반대)
  - 학습된 잠재가 기저 6차원 상태에 일관되게 대응한다(Unresolved)
  - 수학적 대응과 미분동형(Unresolved)
  - 대치 효용에서 병치 대비 우위(서술상 없음)
- 상세는 `phase8_mathematical_conclusions_20261031.md` §5에 있다.

### P8.Z.7 다음 단계로 가기 전 미해결 검증 항목
1. ChatGPT 재감사: 번들 ZIP과 두 문서
2. 사용자 승인 후 프로토콜 v2 §14에 두 번째 launcher 변경(날짜 형식 검사)을 추가할 것
   - 현재 FREEZE_CHANGES에만 있다(감사 F3).
   - 추가하려면 고정 해시를 다시 갱신해야 한다.
3. 프로토콜 §4.5 M-1의 Bernstein 보조판이 구현되지 않았다(서술, 판정 영향 없음).
4. R1과 O_lat 쪽 SSE는 L1 수준으로만 검증했다(재적합·재추론하지 않음).
5. 드라이버 변경이 수치에 미친 영향은 검증할 수 없다(사후 민감도만 있음).
6. 새 실험, 손실, 구조는 아직 하지 않는다(Phase 9 미승인).

### P8.Z.8 감사 문서 경로
- **감사 보고서:** `results/notes/phase8_postrun_independent_audit_20261031.md`
- **수학적 결론:** `results/notes/phase8_mathematical_conclusions_20261031.md`
- **검증 코드, 출력, 로그, 고정 증거:** `results/audit/phase8_postrun_20261031/`(README.md 참조)
- **검증 번들(ChatGPT 업로드용):** `results/audit/phase8_postrun_verification_bundle_20261031.zip`
  - 번들에 넣지 않은 전체 자료 목록: `results/audit/phase8_postrun_verification_bundle_20261031_FULL_DATA_LIST.txt`
- **이 갱신 전 스냅샷:** `results/notes/handover_snapshots/handover_20261031_actual1905_before_phase8_audit.md`

## P8. Phase 8 상태 (2026-10-29) → `results/notes/phase8_mathematical_protocol.md` (DRAFT, 미고정)

### P8.F Gate D — 실행 (11:17 시작 기록)
- **직전 확인:** `labres-check`(11:16)로 GPU 0, 1 · 08:53~17:53 진행 중, 경고 없음, GPU 유휴를 확인했다.
- **실행 명령:** `bash experiments/phase8/launch_p8.sh "2026-10-29 17:53" 24`(11:17:12). 고정 해시 813개 검증과 예약 검사를 통과했다.
- **운영 주의:** launcher는 **단독 명령**으로 실행해야 한다. 처음 시도는 같은 셸 명령 안에 `pgrep … experiments/phase8/gen8.py` 문자열이 있어서 작업 프로세스 검사가 그 셸 자체를 잡았고, 보수적으로 거부했다. 실제 작업 프로세스는 없었고 아무것도 실행되지 않았다. 고정 파일은 수정하지 않았다.
- **로그:** `results/extra/phase8/logs/{launch.log, gen8.log, sched8.log, sched8.stdout, <task>.log}`. 영구 실패는 `results/extra/phase8/failed/`다. 분석은 `results/extra/phase8/analysis/LATEST`가 가리킨다.
- **상태 확인:** `tail results/extra/phase8/logs/sched8.log`, `grep -c "end train" results/extra/phase8/logs/sched8.log`, `labres-check`
- **재개(다음 예약):** 같은 launcher를 새 종료 시각으로 단독 실행한다. 완료된 작업은 건너뛰고, 마감에 종료된 작업은 재개하며, 영구 실패는 재시도하지 않는다.
- **결론 규칙:** 결론은 complete 분석 판본의 완성된 독립 복제본과 사전등록 규칙에만 근거한다. partial 판본의 미완 셀은 미실행/결론 불가다.

### P8.H 계획된 중지 — 서버 GPU 설치 (13:19)
- **중지 순서**
  1. 자동 재개 감시자 종료(재부팅 전 재실행 방지)
  2. 파이프라인 프로세스 그룹에 SIGTERM. 남은 프로세스 0, GPU 메모리 0 MiB.
  3. `sync`
- **진행:** 1,276개 중 **432개 완료**, 실패 0개, 남은 작업 844개
  - 학습 322 / 864, O_lat 69 / 192, 평가 33 / 96
  - p = 0.7 풀 oracle 8개 완료. p = 0.7은 638개 중 432개 완료
  - p = 0.3 작업, k-NN, D5b, 포화, P7 대치는 미시작
- **중지 시 실행 중이던 작업 24개:** 완료 표지가 없으므로 재개 때 처음부터 다시 실행한다(원자적 표지 설계). 실패로 기록하지 않았다.
- **무결성 확인**
  - 학습 행은 모두 valid이고 checkpoint와 짝이 맞는다.
  - checkpoint, oracle, 평가 파일이 모두 로드된다.
  - tmp 잔여 파일 0개, 고정 해시 813개 검증 OK
- 분석은 아직 하지 않았다(결과 미열람).
- **재개:** `RESUME.md`를 따른다. 순서는 `labres-check` → GPU 구성 비교(`logs/gpus_before_shutdown.txt`) → 고정 검증 → `bash experiments/phase8/launch_p8.sh "<예약 종료>" 24`(단독 명령)이다. 완료된 작업은 다시 하지 않는다.
- **주의:** GPU 설치로 장치 번호, PCI 순서, 모델, 드라이버가 바뀔 수 있다. 바뀌었으면 `FREEZE_CHANGES.md`에 기록한다(코드 변경 없음, 실행 환경 변경).

### P8.G 예약 연장과 자동 재개 (12:57)
- `labres-check`(12:56)로 GPU 0, 1 · 08:53~**22:53**을 확인했다. 사용자가 예약을 연장했다.
- **진행(12:57):** 작업 320개 완료(rc = 0), 실패 0개, 두 GPU 사용률 100%.
- **조기 상태 점검(12:02):** 학습 28개가 모두 유효했다. nonfinite 0, 상한 도달 0이고, 파라미터 수가 프로토콜과 일치하며, 코드 해시는 한 종류(`ac9738fc`)다.
- **실행 중 파이프라인의 마감은 바꾸지 않았다.** 환경 변수로 고정돼 있으며, 실행 중 작업을 중단하지 않기 위해서다.
- **자동 재개 감시자**(`results/extra/phase8/logs/autoresume.sh`, setsid로 분리 실행; 고정 대상 아님, 오케스트레이션만 담당)
  - `PIPELINE END`를 기다린다.
  - complete 분석이 없으면 `launch_p8.sh "2026-10-29 22:53" 24`를 단독으로 다시 실행한다. 이때도 고정 해시, 예약, 잠금을 재검증한다.
  - 마감에 종료된 작업은 재개하고, 완료된 작업은 다시 하지 않는다.
  - 로그: `results/extra/phase8/logs/autoresume.log`

### P8.E Gate C — 해시 고정 (11:16)
- **고정 파일:** `results/extra/phase8/PROTOCOL_FREEZE_p8.txt`(2026-10-29 11:16:01 KST, SHA-256 `86243a77e2e806d7a996adb4f47bac17a4963ca863e572c4248ac391ebdf07d2`, 읽기 전용). 다음 해시 813개를 담는다.
  - A: 프로토콜 v2와 검토·보고 문서 10개(v1, crosswalk, Gate B, precheck, regression, 테스트 로그 3개 포함)
  - B: `experiments/phase8` 전체 코드, launcher, 테스트
  - C: Phase 5–7 의존 코드 12개
  - D: 읽기 전용 입력(Phase 6 정규화 풀 8개, P7 동결 기록, P7 checkpoint 288개, P7 자료 480개)
- **고정 시점:** Phase 8의 자료, 학습, oracle, 평가, 분석이 하나도 없었다.
- **검증:** `grep -E '^[0-9a-f]{64}  ' results/extra/phase8/PROTOCOL_FREEZE_p8.txt | sha256sum -c`
- **고정 후 변경 기록:** `results/extra/phase8/FREEZE_CHANGES.md`(현재 없음)와 v2 §14
- **재현 명령**
  - 테스트: `PYTHONPATH=.pydeps:. $PY experiments/phase8/tests/test_phase8.py`
  - 실행·재개: `experiments/phase8/launch_p8.sh "<예약 종료>" 24`
  - 분석(재집계): `PYTHONPATH=.pydeps:. $PY experiments/phase8/analyze8.py`

### P8.D Gate B 최종 회귀 (11:15) → `results/notes/phase8_gateB_regression.md`
- **ChatGPT 최종 검토:** 수학 설계는 조건부 승인됐고, 실행 코드 4건의 수정이 요구됐다.
- **반영한 4건**
  - (1) 무효 AE 실행은 표지와 checkpoint 없이 실패 기록만 남기고, 하류 작업은 시작하지 않으며, 영구 실패는 재시도하지 않는다.
  - (2) 분석을 partial/complete 판본 디렉터리로 나누고 입력이 바뀌면 재집계한다. 이전 판본은 보존하고 `analysis/LATEST`를 둔다.
  - (3) T1–T5 우선순위로 p = 0.7 필수 작업이 탐색 작업보다 먼저 실행된다.
  - (4) `run.lock`, 같은 사용자 프로세스 검사, `sched8.lock`으로 중복 실행을 막는다.
- **테스트:** 21/21 PASS(`phase8_gateB_test_log_v3.txt`). 실패 주입, 재개, 우선순위, 중복 실행 테스트를 포함한다.
- **v2 §9, §11–14 갱신:** 판정, 대비, 상수는 바뀌지 않았다. 작업 수는 1,276개다.
- **재개 절차(다음 예약):** `experiments/phase8/launch_p8.sh "<새 예약 종료 YYYY-MM-DD HH:MM>" 24`를 다시 실행하면 된다. 완료된 작업은 건너뛰고, 마감에 종료된 작업은 재개하며, 영구 실패는 보고만 한다.

### P8.C 최종 사전 점검 + 실행 준비 (10:46) → `results/notes/phase8_final_precheck.md`

**GPU 예약 (현재 상태; 이 절이 우선한다)**
- `labres-check`(10:30): fai-L40S **GPU 0 · 08:53~17:53, GPU 1 · 08:53~17:53**(진행 중, 경고 없음). 이는 사용자가 새로 잡은 예약이다.
- 장치 매핑은 `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0,1`이다(PCI 49:00.0 / 4E:00.0, L40S 46 GB, 확인 시 유휴).
- **이전 handover 기록의 GPU 정보는 현재 상태가 아니다:** "10/29 08:39 만료", §P8.B의 "차단: GPU 예약 없음", §P7의 예약 정보.
- **실행 제한:** `launch_p8.sh "2026-10-29 17:53"`은 DEADLINE = 17:18(새 작업 금지), HARD = 17:48(실행 중 작업 종료)을 쓴다.
- 이 세션의 GPU 사용은 **합성 텐서 타이밍 벤치마크 약 1분(GPU 0)뿐**이다. 프로젝트 자료는 쓰지 않았고 저장한 것도 없다. 실험 GPU 작업은 0이다.

**시간 추정 (합성 벤치마크 + P7 처리량)**
- 단일 프로세스 step 시간: oracle 1.4 ms, AE 6.9 ms
- AE 864개는 약 3.75시간이고, oracle과 O_lat과 평가가 1.5–2.5시간을 더한다(일부 겹침). 자료 생성(CPU)은 약 30분이다.
- 약 12:00에 시작하면 p = 0.7(확증 전부)은 완료 가능성이 높다. p = 0.3(서술)은 일부 미실행일 수 있다.
- 설계를 축소하지 않고 p = 0.7을 우선 배치했다. 전체 완료가 필요하면 예약 연장이 필요하다.

**최종 점검에서 발견하고 반영한 것 (고정 전, v2 §14 기록)**
- F1: 반대 방향 진술(격차 없음, 병치 우위)의 α 이중 사용 → 서술로 격하
- F2: Family I 추론 대상 = 학습 절차의 기대 초과위험
- F3–F5: sched8의 p = 0.7 우선, DEADLINE과 HARD_DEADLINE 필수, 모든 출력 표지를 마지막에 원자적으로 기록
- F6: 강제 종료된 평가의 부속 파일 때문에 분석 KeyError → acc 표지 기준으로 수정. **새 테스트가 잡은 실제 결함**이다.
- F7: 미완 셀 → 미실행 / 결론 불가
- F8: launcher `launch_p8.sh` 추가(고정 해시와 예약을 검증하고 setsid로 분리)

**테스트:** 20/20 PASS(`results/notes/phase8_gateB_test_log_v2.txt`). 추가된 테스트는 스케줄러 hard-deadline 종료, 마감 미설정 시 거부, 우선순위 순서, 원자적 쓰기, launcher 거부, 미완 셀 처리다. 원래 Gate B 기록(18/18 로그)은 보존한다.

**차단 이슈:** 없음. 비차단 위험은 검토 원문 미수신, ½·1-NN 인용, O_lat 폭 고정, 게이트 UNDETERMINED 가능성, p = 0.3 시간 부족 가능성이다.

**Gate C 절차 (승인 후)**
1. v2, `experiments/phase8/*`, 테스트, 의존 파일의 SHA-256을 `results/extra/phase8/PROTOCOL_FREEZE_p8.txt`에 기록한다.
2. 테스트를 재실행한다.
3. `labres-check`를 확인한다.
4. `experiments/phase8/launch_p8.sh "2026-10-29 17:53" 24`를 실행한다.

**시각 표기 정정:** 아래 스냅샷 파일 이름의 시각은 실제 기록 시각보다 앞서 있다(파일 이름은 보존).

| 파일 이름 | 실제 mtime |
|---|---|
| …0915_pre_phase7_final | 09:04 |
| …0920_phase7_final | 09:05 |
| …0950/0955 | 09:26 |
| …1000/1005 | 09:41 |
| …1030/1035 | 09:59 |
| …1125/1130 | 10:21 |

- §P8.A의 "10:35"는 실제 09:59이고, §P8.B의 "11:30"은 실제 10:21이다.
- 이후 스냅샷 이름에는 `actualHHMM`(서버 시계)을 쓴다.

### P8.B Gate B — 프로토콜 무결성 완료 (11:30) → `results/notes/phase8_gateB_integrity.md`

**코드:** `experiments/phase8/{core8, gen8, train8, feats8, oracle8, knn8, evaluate8, eval_p7imp8, analyze8, sched8}.py`(약 1,300줄)
- Phase 5/6/7 모듈은 import만 하고 수정하지 않았다.
- 새 손실이나 AE 구조는 없다. oracle MLP는 진단 도구다.

**테스트:** `experiments/phase8/tests/test_phase8.py` **18/18 PASS**. 로그는 `results/notes/phase8_gateB_test_log.txt`다. 다루는 범위:
- seed 비중첩, 상수와 문서의 일치(31개 문자열)
- Arm 표와 파라미터 수
- 포획 항등식(sympy), 대칭군 등변성(κ = 1에서 γ₁ 위반 확인), N1 창 불변
- 층 확률과 X0/H = 0.0509, T_A의 1/6
- 게이트 논리, R1 = evaluate6 규칙(비트 동일), past-only, k-NN
- D5b 정확 조건부 추출, 작업 계획 1,277개와 dry-run 부작용 없음
- P7 대치 경로(무작위 가중치 mock, P7 결과 미계산)
- smoke는 CPU만 사용
- **CPU end-to-end smoke**(작업 125개 실패 0, Sham 교환 = Real 배열 동일, oracle은 풀 id만 읽음, smoke 산출물 분석 거부)
- 이전 Phase 파일 불변

**Gate B 중 수정한 결함**
- smoke의 GPU 사용 가능성 차단
- D5b 기각 추출 무한 루프 → 정확 조건부 추출
- k-NN 위험 합산 오류
- 실질 효과 판정의 방향성
- dry-run 부작용
- Family I 부호 검정 누락

**v2 변경(고정 전, §14 기록):** 실행 도구를 sched8로 정했고, feats8을 명시했고, D5b 추출 방식을 명시했다.

**남은 위험(비차단)**
- ChatGPT 원문 미수신
- ½·1-NN 인용 미검증
- O_lat 폭 고정
- κ = 0 게이트 UNDETERMINED 가능성
- H와 δ_I는 P7을 보고 선정(새 자료로 확증)

**차단:** ~~GPU 예약이 없다(Gate D).~~ → **§P8.C로 대체됨**(새 예약 08:53~17:53 확인).

**다음:** 사용자 승인 시 Gate C(해시 → `results/extra/phase8/PROTOCOL_FREEZE_p8.txt`). 이어서 예약 확인 후 `gen8.py 60` → `sched8.py NPAR`를 실행한다.

**재현(CPU)**
- `PYTHONPATH=.pydeps:. $PY experiments/phase8/tests/test_phase8.py`
- `env -u P8_SMOKE PYTHONPATH=.pydeps:. $PY experiments/phase8/sched8.py 24 --dry`

### P8.A Gate A — 수학 개정 완료 (10:35)

**문서**
- v2 프로토콜: `phase8_mathematical_protocol_v2.md`
- 대조표: `phase8_revision_crosswalk.md`(ChatGPT 12항목 + R1–R6)
- ChatGPT 보고서의 원문은 받지 못했다. 대조는 사용자가 요약한 12항목 기준이다.

**핵심 개정**
- **P와 ν의 분리:** 모든 Bayes 위험은 유한시간 a.c. 평가 법칙 P에 대해 정의한다. 콤팩트 불변집합은 vol = 0이다(L3b). L4/L5/C1은 P에서의 결과이며 ν로 확장하지 않는다.
- **대칭군:** γ₁₂와 π는 모든 κ에서 흐름과 가환하고, γ_j는 κ = 0에서만 가환한다.
- **N1 하한:** LB = (1/6) Σ m_c/σ_c²(모집단 2차 모멘트, 고정 상수). 2/3과 1/3은 분산 일치 조건에서만 정확하다. 설계 단계 값은 0.6667–0.6677(P7 train)이다.
- **T_A:** 1/6 정규화를 넣었다.
- **포획 경계:** V(t) ≤ 3850.667을 검산했고, 더 좁은 3080.533을 증명했다. 수치 max는 2,551이다.
- **k-NN:** D4형 유효 상한 + Stone 조건(i.i.d. 참조 = 궤적당 시각 1개). ½·1-NN은 점 추정이고 인용은 미검증이다.
- **H와 X0:** X0는 H의 5.1%다.
- **Family II를 CSIA로 재정의:** GSR은 확증 대상이 아니며, 다중 서술 기준만 둔다.
- **κ = 0 게이트:** j별 정확 부호 검정 + TOST ε = 0.01. 결과는 PASS / FAIL / UNDETERMINED다.
- **G_lat:** 학습된 두 함수의 위험 차이로 정의했다.
- **검정력:** 최소 d_z = 0.60 / 0.67(80%)이다. 0.99 주장은 철회했다.

**설계 수정**
- Fact8Sham의 정확한 교환을 위해 donor로 학습한 A_o^♯를 추가했다(학습 864개).
- BfullSham을 j별 두 Arm으로 나눴다.
- j 평균 CG는 대칭이 보장되지 않는다. 기댓값 0만 성립하므로 정확 검정은 j별로 한다.

### P8.R 검토 대기 상태 (10:05) → 자체 검토 `results/notes/phase8_protocol_review_notes.md`

**공유 패키지:** `results/review_packages/phase8_protocol_review_20261029/`(+ `.zip`)
- 원문 그대로의 프로토콜: SHA-256 `c5e37088…1eea`, 446줄
- 행 번호 판 `.numbered.txt`, 자체 검토 문서, README, SHA256SUMS
- **검토 행 번호는 이 해시 기준이다.**

**자체 검토 결과 (원본 미반영; 심각도 S1 = 고정 전 필수 수정)**
- **R1 [S1] D5(83행), 181, 227, 436행:** "1-NN Cover–Hart 일관성" 표현이 부정확하다.
  - 1-NN 예측기의 위험은 2R*로 가며 Bayes 일관적이지 않다. ½·1-NN은 잔차분산 추정량으로, 별개 조건을 가지며 인용이 아직 미검증이다.
  - 수정안: k-NN oracle은 D4형 **유한 표본에서 유효한 상한**이다. 조임 근거는 Stone 정리(i.i.d., k → ∞, k/N → 0, E‖S‖² < ∞)다. 참조 DB를 "독립 궤적당 시각 1개"로 바꿔 i.i.d.를 확보한다(연속 창은 의존 표본이고, 대상 법칙이 정상이 아니라서 혼합 정리도 쓸 수 없다).
- **R2 [S1] L4(117–124행), L5, C1, §3 정의(115행), §3 정리(166행):** n_obs < 6 ⇒ R* > 0은 **A-ac(평가 법칙이 Lebesgue 절대연속)** 아래에서만 성립한다.
  - 생성 법칙 P에서는 참이다(L3). 그러나 크기를 말하지 못하고, 수치적으로 검증할 수도 없다.
  - 콤팩트 불변집합은 vol = 0이다(발산이 상수이고 음수, Verified math). 그래서 끌개 위 불변측도에서는 A-ac가 거짓이고, 명제가 성립하지 않을 수 있다(Unresolved).
  - C1은 "P 아래의 형식적 반례"로 격하한다. §3 정리는 "방법론적 원칙"으로 바꾼다(Verified (math) 라벨 철회 제안).
- **R3 [S1/S3] N1(131–141행), C3, T_A(204행), P8.4:** 정확한 조건을 정리했다.
  - 대칭: X0에서는 모든 κ에서 Γ×Γ, κ = 0 L_j0에서는 Γ_j×Id만 쓴다.
  - 마스크 ⊥ 상태 경로, t ≥ 7, 층 ∈ σ(M) ⊂ σ(W).
  - LB = (1/6) Σ_{xy 좌표} E_P s_c²/σ_c²다. **4/6, 2/6은 σ_c² = Var_P(s_c)일 때만 정확하다.** 실제 σ_c는 풀 표본 SD이므로 근삿값이고, LB 수치는 독립 자료로 추정한 통계량이다.
  - 표기 수정: T_A 점별 양은 6 × (R − LB)이고, R*(y_j | W_j, L_j0)는 정규화 단위의 좌표 하나 위험이다.
- **R4 [S2] 26, 234, 246–247, 280, 313, 322행:** Fact 대 B-full 비교의 범위를 좁힌다.
  - IIb-1이 검출되어도 "readout 부류 R1에서 결합 정보의 F-접근성"일 뿐이다.
  - 다른 설명(Fact 인코더 손실 C5, Sham 학습 분포, 함수 부류와 최적화 step 2배)을 구별하지 못한다.
  - 비슷한 파라미터 수 ≠ 같은 용량. 낮은 RMSE나 Δ_JF < 0 ≠ 공유 상태 좌표나 diffeomorphism.
  - 명칭은 "결합 정보 활용의 통제 검증"으로 바꾸고, "genuine shared-state"는 정의된 다중 기준으로만 쓰자는 제안이다.
  - 강화안: P8.4 인증이 성립하면 "F는 W_j의 a.s. 함수가 아니다"가 된다(잠재 자체에 대한 하한 논리).
- **R5:** 기타
  - 105행: Bayes 예측기 마스크 분산 > 0의 증명을 추가한다(x_j(t) 관측 마스크 대 X0).
  - 240행: 3좌표 평균 정의를 명시한다.
  - 254행: donor 1회 사용, GPU 비결정성의 독립을 명시한다.
  - 62행: C_V는 아직 계산하지 않았다.
  - 208–209행: oracle 풀 조건부 문구를 판정 문장에 넣는다.

**미해결 수학적 쟁점 (고정 전후 모두 추적)**
1. 끌개(불변측도) 위의 식별가능성. 고정 좌표 관측이라 SYC를 바로 적용할 수 없다.
2. 대칭 밖 층의 정량적 Bayes 하한 도구가 없다.
3. k-NN과 잔차분산 추정량 인용의 원문 대조
4. N1 정규화 상수 대 진짜 모멘트, LB 추정 오차 처리(M-2)
5. 결합계 포획 상수 C_V(M-1)
6. IIb에서 "인코더 손실 대 결합 형성"을 분리하는 설계(미설계)
7. Phase 6/7부터 이어진 미해결: L1/L2+ Δ*, G2 κ = 0 대조 실패, p = 0.7 H3 실패의 원인

**다음 단계:** ChatGPT 원문 검토 수신 → 자체 검토와 대조 → 프로토콜 개정판(§13 변경 기록) → 해시 고정 → 코드와 CPU 테스트 → (승인 시) GPU 예약 확인 후 실행

**스냅샷:** `handover_20261029_1000_pre_phase8_selfreview.md`(갱신 전), `handover_20261029_1005_phase8_review_pending.md`(갱신 후)


**지시 요지:** 새 구조나 손실 없이 두 가지 문제의 엄밀한 프로토콜을 먼저 쓴다. 독립 검토 후 고정하고 확증 실험을 한다.
- (I) 정보 한계 대 모델 한계. 마스크 조건부 Bayes 위험 R*(S | W_M, M)의 정의, 유효 하한과 oracle 상한의 구분.
- (II) Factorized baseline으로 진정한 공유 상태 표현을 통제 검증한다.
- 결측 위치 imputation 평가를 추가한다.

**프로토콜의 핵심 수학 (Verified (math), 증명 스케치는 문서 §2–§5)**
- **B1:** E_A(h) ≥ R_A(h) − R_A(f_oracle). 모델 한계의 하한이다.
- **B3:** latent와 raw의 readout 차이는 Bayes 정보 손실의 하한이 아니다("F-접근 가능 위험").
- **B4:** 잠재 16차원은 Bayes 병목이 아니다(m(W) ∈ R⁶).
- **§2.3 항등식:** MSE = 마스크 분산 + 마스크 평균 편향이고, SD² ≤ MSE다. Bayes 예측기도 마스크 분산이 0보다 크다.
- **L4/L5:** n_obs < 6(κ = 0 자기 하위계는 n_own < 3)이면 R* > 0이다. 정성적일 뿐이며, 밀도가 끌개에 지수적으로 집중되므로 크기는 말하지 못한다.
- **N1 대칭 하한**
  - X0(창에 x1, x2 관측 없음)에서는 모든 κ에서 LB ≈ 4/6이다.
  - κ = 0, L_j0에서는 LB ≈ 2/6이다.
  - 자기 창만으로는 R*(y_j | W_j, L_j0) = E y_j²이다.
- **반례**
  - C1: L_j ≥ 2는 충분조건이 아니다(κ = 0, L_j = 2, z 관측 없음 → R* > 0, 확률 0.017).
  - C2: 국소 ≠ 전역.
  - C3: 좋은 imputation ⇏ 숨은 상태 복원.
  - C4: 안정성 ≠ 식별가능성.
  - C5: 주변 충분성 ⇏ 결합 충분성.
- **§3 정리:** 이 무잡음 계에서 정량적 정보 한계는 대칭 층에서만 인증된다. 그 밖에서는 모델 한계의 하한만 인증된다.
- **P8.1:** κ = 0이면 Bayes 인수분해가 성립한다(Bfull 대 Fact의 차이가 교차 정보일 수 없다).
- **P8.2:** 병치 충분성.
- **P8.3:** κ = 0에서 Real과 Sham은 교환 가능하다(정확 부호 검정).
- **P8.4:** 자기 L0 인증. C_F > 0이면 상대 view 정보를 사용한다는 하한 논리다.

**설계 (요약; 고정 전)**
- **Family I (α 0.025):** κ = 1, p = 0.7, H = none_L2+에서 G_tot = R(R1∘φ_Bfull) − R(O_raw) > δ_I = 0.02(MSE) → G_lat → κ = 0 순서.
- **Family IIa (α 0.0125):** κ = 0 게이트 → κ = 1 CG_Bfull(Real − Sham, y_j) < 0 → P8.4 인증.
- **Family IIb (α 0.0125):** κ = 0 게이트 → κ = 1 CG_Bfull − CG_Fact8 < 0 → RMSE_s6(Bfull − Fact8) < 0.
- **Arm (새 학습):** Bfull 57,840, BfullSham, A_j^8(Fact8 55,888, 잠재 합 16), A_j^16(Fact16 63,104, 잠재 32). Fact8Sham은 학습이 필요 없다. 576 학습.
- **Oracle:** O_raw, O_imp, O_own,j, O_lat(MLP 깊이 4, 폭 {256, 512, 1024}를 oracle-val로 선택). 독립 oracle 풀 id 60000+.
- **Family III (서술):** P8 Arm과 **P7 checkpoint**의 결측 위치 대치. 기준선은 0, LOCF, O_imp.
- **Family IV (탐색):** readout 없는 잠재 진단.
- **단위:** 복제본 24. 궤적·마스크·j는 합동한다. p는 대응, κ는 독립으로 다룬다.
- **설계 확률(p = 0.7):** none_L2+ 0.065, X0 0.0033, L_j0 0.0576, n_obs < 6 0.051.

**고정 전 과제:** 독립 검토 반영, M-1(포획 상수 C_V), M-2(LB 모멘트 추정 방식), M-3(1-NN 가정), 코드와 CPU 테스트 작성, 해시 고정.

**GPU:** 사용하지 않았다(프로토콜 단계). 실행 전에 `labres-check`와 예약이 필요하다.

**Phase 8에서 보존하는 Phase 7 음성·미해결 결과**
- 주 효과는 결합 활용의 증거가 아니다(κ = 0에서도 같다).
- p = 0.7 H3 실패
- L0 정보 미실현(1.019)
- G2 κ = 0 대조 실패(Phase 6)
- L1/L2+ Δ* Unresolved

**스냅샷:** `handover_20261029_0950_pre_phase8_protocol.md`(갱신 전), `handover_20261029_0955_phase8_protocol_draft.md`(갱신 후)

## P7.0 Phase 7 결론 (2026-10-29) → `results/notes/phase7_final_report.md`

**완료 상태 [Verified (code/data)]**
- 학습 288/288 rc=0, 상한 도달 0, nonfinite 0, code_md5 1종(a9f00fb6), CFG 1종, n_params 57,840.
- 평가 96/96 rc=0, Oracle Jacobian 48/48, analyze7 rc=0(10/28 23:06). 동결 해시 17개 OK. 테스트 6/6 PASS.
- 독립 재구현(`verify7.py`)이 주 대비를 정확히 재현한다.
- 편차
  - (1) run_lane7.sh·eval_sched7.py 해시는 학습 시작 직후(첫 결과 전) 동결 기록에 추가됐다.
  - (2) 사전등록 보조 "p 차이"는 analyze7에 구현이 누락돼 사후 구현했다(복제본 대응).

**주 결과 [Empirical, 사전등록 확증]**
- S1–S4가 모두 확증됐다. Δ = Q(Bfull) − Q(Bself), RMSE_s6 기준이다.
  - S1(1, 0.7): −0.370 [−0.376, −0.365]
  - S2(1, 0.3): −0.255 [−0.263, −0.248]
  - S3(0, 0.7): −0.409 [−0.411, −0.407]
  - S4(0, 0.3): −0.662 [−0.665, −0.659]
  - 모두 24/24이고, CI 상한 < −δ₆(0.05)다.
- 이득은 거의 전부 상대 하위계에서 온다. 자기 하위계는 p = 0.7에서 +0.022–0.037 나빠진다(24/24).
- Bfull < raw_joint(−0.035 ~ −0.061, 24/24). DPI 때문에 Bayes 우위가 아니라 추정 용이성이다.

**해석**
- H2 일부 해결 [Empirical]: 이 구조에서 B-self의 6차원 실패 원인은 **학습 목표**다(구조가 아님).
- 그러나 κ = 0에서도 이득이 같다. 따라서 **결합 동역학(교차 정보)의 활용 증거가 아니다**(M2). 자기 L0 층에서 G1이 인증한 정보도 공유 readout에서 실현되지 않는다(1.019).
- H3
  - p = 0.3: Phase 6 G3 기준(RMSE ≤ 0.2, SD ≤ 0.1, raw보다 우수)을 all과 both_L2+ 층에서 처음 만족한다 [Post-hoc 적용].
  - p = 0.7: 어느 층도 만족하지 않는다. 마스크 간 SD 0.27 ≈ RMSE 0.31이다.
  - 전역 단사성, diffeomorphism은 Unresolved다.
- H1: P7-B는 새로 검정하지 않았다(Phase 6 / P7-A 상태 유지).

**가장 방어 가능한 기여:** 손실 열만 바꾼 단일 변인 비교로, 공유 상태 실패의 원인이 목표임을 사전등록·독립 복제로 확증했다. 동시에 그 이득이 결합 활용이 아님을 κ = 0 대조로 보였다.

**다음 수학 문제(최우선):** 층별(L1, L2+, both_L2+) 마스크 조건부 Bayes 위험 R*(s6 | W_M, M)의 계산 가능한 하한을 추정 오차를 통제한 채 구한다.
- 이것이 있어야 p = 0.7 실패가 관측 한계(H1)인지 모델 한계(H2)인지 가를 수 있다.
- 부수 과제: 마스크 불변 식별가능 집합의 정의, 결합 활용 측정 대비(κ 대조, Sham 상대 view).

**산출물 (Phase 7 종료 시)**
- 보고서: `results/notes/phase7_final_report.md`
- 사후 검산
  - 코드: `experiments/phase7/verify7.py`
  - 출력: `results/extra/phase7/verify/`(`verify_summary.txt`, `v_*.csv`, `v_own_L0_yj.txt`)
- 검증 패키지: `results/review_packages/phase7_20261029/phase7_review_documents.zip`, `phase7_verification_bundle.zip`(각각 FILE_INDEX.md, SHA256SUMS 포함)
- 스냅샷: `results/notes/handover_snapshots/handover_20261029_0915_pre_phase7_final.md`(갱신 전), `handover_20261029_0920_phase7_final.md`(갱신 후)

**GPU:** 10/29 08:39에 예약이 끝났다. 남은 GPU 프로세스는 없다. Phase 8 GPU 작업 전에 `labres-check`와 예약이 필요하다.

**재현 (CPU, 학습 없이)**
- `PYTHONPATH=.pydeps:. $PY experiments/phase7/analyze7.py`
- `PYTHONPATH=.pydeps:. $PY experiments/phase7/verify7.py`
- `CUDA_VISIBLE_DEVICES= PYTHONPATH=.pydeps:. $PY experiments/phase7/tests/test_phase7.py`
- `$PY`는 `/home/minju/.conda/envs/reef_gpu/bin/python`이다.

## P7. Phase 7 실행 기록 (2026-10-28; 아래 "실행 중" 표기는 당시 상태이며 §P7.0이 최종)

**Official AIM (원문, §1과 같음)**
> 완전 관측 변수 없이 다변량 시계열의 결측을 복원하는 동역학 기반 대치 프레임워크. Takens 정리가 시사하듯 모든 변수의 지연 매장이 일관되게 사상되는 공유 잠재 상태를 학습한다.

**Phase 7 지시 요지:** Phase 6에 대한 독립 검토 결과를 반영해 수학적 진술을 정정한다(P7-A). 그리고 자기 목표(B-self)와 전체 목표(B-full) 복원 감독을 비교하는 중심 실험 하나를 수행한다(P7-B).

**현재 수학적 가설 (P7-B)**
- B-self의 잠재가 상대 하위계를 버리는 이유는 학습 목표다(Hypothesis).
- 전체 view 감독은 공유 readout의 6차원 복원을 개선한다(Hypothesis, 반증 가능).

**GPU:** fai-L40S GPU 0, 1, 예약 10/29 08:39까지(사용자 연장). lane guard는 epoch 기준 08:20이다.

### P7.A Gate P7-A — 완료 (21:38) → `results/notes/phase7_mathematical_corrections.md`
- 재계산(새 코드, 원본 합 CSV): `experiments/phase7/p7a_recompute.py` → `results/extra/phase7/p7a/g1_recompute.csv`.
  - L0 0.041065 / LCB 0.032181 / 전체 0.001855, L0c0 0.035286 / LCB 0.027380을 재현했다.
  - 다른 seed와 t 하한에서는 0.0266–0.0318이다.
- **A1:**
  - 모집단 부등식 Δ* ≥ p⁸ G_L0(f)는 Verified (math)다.
  - Δ* > 0은 근사 bootstrap LCB에 근거한 **Empirical**이다. 유한 표본 coverage는 증명되지 않았다.
  - "Bayes 정보의 양성을 수학적으로 증명"이라는 표현은 철회한다.
- **A2: 명제 P7.1 [Verified (math)]**
  - E[y_j | U_j, V_cur, L0c0] = 0. 가정은 생성기 법칙의 Γ×Γ 불변(대칭 초기분포 + 등변성)과 MCAR이다.
  - 따름정리: R*(U, V_cur | L0c0) − R*(U, V_full | L0c0) ≥ G_L0c0(f). 값은 0.035286, 근사 LCB 0.027380이다.
  - 해석: 상대 view의 **과거** 관측이 현재 관측으로는 풀리지 않는 부호 모호성을 부분적으로 해소한다[Empirical].
  - 기제(상태 복원인지 과거로부터의 시간적 외삽인지)는 Unresolved이며, 강한 state-space reconstruction과 동일시하지 않는다.
- **A3:**
  - G2 κ = 0, p = 0.7 음성 대조 실패는 **미해결**이다.
  - S1R은 결과를 본 뒤 설계한 새 독립 재현이며, 원래 사전 등록 가족이 아니다.
  - 보수적 해석: S1 보류에서 고정 순서가 멈춘다. S3는 개별 유의(FWER 확증 아님)이고, S2는 서술적이다.
- **A4:**
  - G3 음성 결과는 자기 목표 AE에 국한된다.
  - raw 대비 우월성은 공유 표현의 수학적 필요조건이 아니다(DPI: Bayes 수준에서 잠재 ≤ raw).

### P7.B Gate P7-B — 실행 중 → 프로토콜 `results/notes/phase7_p7b_protocol.md`(21:40 고정, `results/extra/phase7/PROTOCOL_FREEZE_p7b.txt`)
- 설계:
  - Bself1, Bself2, Bfull: 같은 4-view 입력, 같은 4-view 전체 decoder, 같은 파라미터 수와 초기 가중치, 같은 마스크와 숨김 RNG. **손실 활성 열만 다르다.**
  - 그래서 유효 gradient 경로와 감독량, 조기 종료 열이 다르다(명시).
  - 새 독립 궤적 id 40000+, 복제본 24 × κ{0, 1} × p{0.3, 0.7}, 학습 288개.
- 주 결과: RMSE_s6(공유 MLP 2 × 128 readout, test 8 × 마스크 5).
- 주 대비: Bfull − mean_j Bself_j. 고정 순서 S1(κ = 1, p = 0.7) → S2(1, 0.3) → S3(0, 0.7) → S4(0, 0.3), δ₆ = 0.05.
- 코드: `experiments/phase7/{core7, train7, gen7, jac7, evaluate7, eval_sched7, analyze7}.py`, `run_lane7.sh`.
- 테스트 `experiments/phase7/tests/test_phase7.py` 6/6 PASS(학습 전). 비활성 head의 gradient가 0임을 포함한다.
- 실행: lane 24개(21:40 시작), 평가 스케줄러, Oracle Jacobian 48개(완료).

**재현 명령 (Phase 7)**
- `PYTHONPATH=.pydeps:. python experiments/phase7/p7a_recompute.py`
- `python experiments/phase7/gen7.py 56`
- `python experiments/phase7/tests/test_phase7.py`
- `DEADLINE_EPOCH=… experiments/phase7/run_lane7.sh GPU results/extra/phase7/runs/lanes/main_part_Q.txt LOG`
- `python experiments/phase7/jac7.py 12`
- `python experiments/phase7/eval_sched7.py 4`
- `python experiments/phase7/analyze7.py`

## P6. Phase 6 상태 (2026-10-28)

### P6.0 한눈에 보기 (다음 세션은 여기부터 읽는다)

**Official AIM (원문, §1과 같음)**
> 완전 관측 변수 없이 다변량 시계열의 결측을 복원하는 동역학 기반 대치 프레임워크. Takens 정리가 시사하듯 모든 변수의 지연 매장이 일관되게 사상되는 공유 잠재 상태를 학습한다.

**Phase 6 결론 (라벨 포함, 상세는 최종 보고)**
- **Q1 정보 존재(H1):**
  - κ = 1, p = 0.7에서 Δ* ≥ 0.0019 > 0, L0 층 ≥ 0.032 [Verified (math) + 단측 95% 통계적 하한, 추정 오차 가정 없음].
  - κ = 0에서는 0이다 [Verified (math)].
  - L1, L2+ 층(시각의 94%)은 Unresolved다.
- **Q2 모델 활용(H2):**
  - Real MV > Sham MV. S1R은 −0.0104 [−0.0141, −0.0068], 23/24, 음성 대조 통과로 **사전 등록 독립 확증**이다. p = 0.3에서는 −0.015, 24/24다. 모두 δ = 0.02 미만이다.
  - **원래 H2(B > A)는 두 독립 표본에서 지지되지 않는다**(B가 +0.012 나쁨). 입력 비용이 정보 이득보다 크다.
- **Q3 정보 경로:** L0c0(x_j 창 없음 + x_o(t) 결측)에서도 Δ* ≥ 0.027(LCB)이다. 순간 항등식과 현재값으로 설명되지 않는 **지연 관측 정보가 존재한다** [Verified (math) + LCB]. L0c1에서는 현재값 경로가 대부분이다.
- **Q4 공유 좌표(H3):** 아니오. 사전 기준을 만족한 AE 잠재가 없다. 자기 목표 AE는 상대 하위계를 버린다. 원시 결합 관측에는 6차원 정보가 있다(raw readout 0.08 / 0.37) [Empirical].
- **Q5:** 아래 P6.1 표와 최종 보고 Q5.
- **Q6 단일 기여:** 대칭으로 Bayes 위험을 정확히 아는 관측 층을 이용해, 다중 지연 관측의 숨은 상태 정보를 **추정 오차 가정 없이** 증명했다. 그리고 정보 존재(H1)와 모델 활용(H2)과 좌표 형성(H3)을 분리했다.

### P6.1 수학적으로 검증된 정리와 정확한 가정 (Phase 6에서 새로 추가/수정)

| 정리 | 가정 | 문서 |
|---|---|---|
| z-only 창은 **적어도** 2:1(κ = 0에서 적어도 4:1) | Γ×Γ(κ = 0에서 Z₂×Z₂) 등변성, Fix 밖의 점 | ER E1 |
| D는 X_T = Φ^T(R⁶)(T ≥ 0.35)와 A_κ 위에서 정의된다 | 순방향 흐름의 존재만 | ER E2 |
| 명제 E3.1: κ = 0, 독립 donor이면 E[B − Sham] = 0(추정량 수준), (B, Sham)은 교환 가능 | 하위계별 독립 초기조건, 동일 파이프라인, donor 독립 | ER E3 |
| 명제 3의 독립성은 고정 t에서 정확, 시간 혼합에서는 정상성 근사 | 독립 초기조건 | ER E4 |
| G1.1: 실험 법칙은 모든 t에서 Γ×Γ, P(κ = 0에서 Γ×Id)에 불변 | 생성기의 대칭 초기분포, 등변성. SRB 불필요 | G1 프로토콜 §2 |
| G1.2: L0에서 E[y_j \| U_j] = 0, R*(U \| L0) = E[y²]. κ = 0에서 Δ*_L0 = 0 | G1.1 + 마스크 독립 | 같음 |
| G1.3: Δ* = Σ P(s) Δ*_s ≥ p⁸ Δ*_L0 | 층이 σ(U)-가측(또는 마스크만의 함수) | 같음 |
| G1.4: 고정 f에 대해 Δ*_L0 ≥ E[y² − (y − f)² \| L0] | G1.2 | 같음 |
| G1.5–6: witness 부등식, 교차적합 편향 = 두 추정 오차의 곱 | Y ∈ L² | 같음 |

**반례와 식별 불가능 조건**
- z-only(모든 κ)
- 자기 L0 + 자기 view만(모든 κ)
- κ = 0 자기 L0 + 상대 view
- κ = 0에서 자기 view로 상대 하위계
- 국소 full rank ≠ 전역 단사(z-only 창)
- L2+는 대칭 반례만 배제하며, 식별가능 집합이 아니다

### P6.2 수정한 기존 명제 (Phase 5 문서는 덮어쓰지 않았다; 정오표 `phase6_mathematical_errata.md`)
- E1 2:1 → 적어도 2:1
- E2 D의 정의역
- E3 Bayes 대 추정량. PR §7 모순 조항 철회. κ = 0 B − A = 0 기대 철회
- E4 고정 t 대 시간 혼합
- E5 L2+ 명칭
- E6 Phase 5 Sham donor 재사용 → t-CI 확증 불가
- E7 MV-shift는 past-only가 아님
- E8 판정 라벨 분리
- E9 "충분하다" 철회

### P6.3 발견된 오류와 영향받는 실험
- **Phase 5 Sham donor 재사용(E6):** Phase 5 사후 B − Sham의 t-CI. 수치는 보존하고 해석만 약화했다.
- **Gate F MV-shift의 미래 노출(E7):** Gate F의 "정렬 이득" 해석을 "정렬을 깬 대조보다 낫다"로 좁혔다. MV-shift − SV 해석은 보류한다.
- **Phase 5 판정 함수 순서(E8):** B − A 라벨. Phase 6에서도 같은 현상이 재현됐다(EQUIV 라벨 + CI > 0).
- **Phase 6 실행 중 오류**
  - (1) 첫 seed base가 Phase 5 시드와 겹쳤다. 학습 전에 테스트가 잡았고 자료를 재생성했다.
  - (2) S1R 첫 lane이 SyntaxError로 학습 전에 모두 종료됐다. 수정 후 재실행했다.
  - 둘 다 결과에 영향은 없다.
- **Unresolved:** G2 κ = 0, p = 0.7 음성 대조 실패(+0.0062, 20/24).
  - 수치 결합은 배제했다(진단 J ≈ S ≈ 0).
  - 새 표본(진단 J, S1R)에서 재현되지 않았다.

### P6.4 미실행 실험과 이유
- Gate F 공정 대조 MV-lag: 제안만 했다(ER E7). GPU를 G1–G3, S1 확증에 우선 배정했다.
- 6차원 목표 AE(C형) G3 시험: 범위 밖(Arm 탐색 최소화). 다음 후보다.
- L1, L2+ 층의 Bayes 하한: R*(U)를 정확히 모르는 층이라 오차 가정 없이는 불가능하다.

### P6.5 다음 연구의 가장 중요한 질문
1. L1, L2+ 층에서 Δ* > 0인가? 추정 오차를 통제한 하한이 필요하다.
2. 학습 방식(마스크 증강, 표본 수)만 바꿔 입력 비용을 줄이면 Real MV의 이득이 순효과(B < A)로 나타나는가? 새 손실은 쓰지 않는다.
3. 6차원 목표 AE의 잠재는 공유 상태 좌표를 형성하는가?
4. G2 κ = 0 대조 실패의 원인.

### P6.6 새 세션에서 읽을 자료 (순서)
1. 이 파일 §P6
2. `results/notes/phase6_final_report.md`
3. `results/notes/phase6_mathematical_errata.md`
4. `results/notes/phase6_g1_protocol.md` → `phase6_g1_results.md`
5. `results/notes/phase6_g2_g3_protocol.md`(§10 S1R) → `phase6_g2_g3_results.md`
6. Phase 5 문서(§1–§10 아래)

### P6.8 Phase 6 독립 수학 검토 패키지 (2026-10-28 21:16 생성)
- 위치: `results/review_packages/phase6_20261028/`
  - `phase6_review_documents.zip`: 문서 7개 + `FILE_INDEX.md`(파일별 SHA-256).
    - 문서: errata, G1 프로토콜·결과, G2/G3 프로토콜(§10 S1R 포함)·결과, 최종 보고, 이 handover의 20:51 버전(이 §P6.8 추가 전).
  - `phase6_verification_bundle.zip`: 파일 3,423개 + `FILE_INDEX.md` + `MANIFEST.json`.
    - 코드: Phase 6 전체, 사후 진단, S1R, Phase 5 의존 모듈, FDR 손실, src 모듈, 테스트.
    - 원본 평가 CSV: G1, G2/G3, 진단 J/S, S1R.
    - 분석 CSV, 학습 rows/logs/lanes.
    - 고정 기록 4개(G1, G2/G3, 진단, S1R), G0 점검 결과.
    - 참조 문서: Phase 5 MF, PR, OA.
  - `FILE_INDEX.md` §A: 검토 항목 7개(L0 정리의 증명, Δ* 하한과 표본 단위, L0c0 근거, 음성 대조 실패와 S1R 기록, donor 독립성과 κ = 0 가정, H3 실패 조건, 사전 등록과 사후의 구분)마다 근거 파일과 절을 안내한다.
  - 제외(해시만 MANIFEST에 기록): 궤적 npz(G2/G1 1,256, 진단 J·S 각 480, S1R 960), 체크포인트(G2 960, 진단 192, S1R 192), Oracle Jacobian npz 48.
  - `SHA256SUMS`, `build_bundle.py`(복사만 하는 생성 스크립트), `_checks.md`(점검 기록).
- 생성 시 점검 (GPU 미사용, 새 학습 없음):
  - 무결성 테스트: phase6 9/9, phase5 8/8, external 3/3 PASS(원 프로젝트).
  - ZIP만 풀어서 `analyze_g1.py`, `analyze6.py`, `s1r/analyze.py`를 다시 실행했다. 출력 CSV 8개가 원본과 바이트 단위로 같다.
  - MANIFEST의 SHA-256이 추출본·원본과 모두 일치한다. 제외 파일은 표본 23개로 확인했다.
- 기존 코드, 결과, 문서는 수정하지 않았다. 새 연구 결론은 작성하지 않았다.
- 이전 handover는 `results/notes/handover_snapshots/handover_20261028_2114_pre_phase6_package.md`에 보존했다.

**검토자에게 확인을 요청할 미해결 사항** (기존 문서에 이미 기록된 항목)
1. G1.1–G1.2: 대칭 논증이 "생성기 법칙"(독립 균등 초기조건 + transient 이후 시각 혼합)에 대해 정확한지. SRB 측도가 아닌 이 법칙을 대상 분포로 정의한 것이 적절한지.
2. G1.4의 인증량과 cluster bootstrap(궤적 32개) 단측 LCB의 타당성. 궤적당 마스크 10개를 합동한 비율 추정량.
3. L0c0/L0c1 분할(상대 마스크의 함수)에서 E[y|U, c] = 0 논증. 그리고 "현재값이 아닌 지연 정보" 해석의 범위.
4. 명제 E3.1(κ = 0 교환가능성)과 G2 κ = 0, p = 0.7 음성 대조 실패(+0.0062, 정확한 부호 검정 p ≈ 0.0015)의 양립. 원인은 Unresolved이고, 진단 J/S와 S1R에서는 재현되지 않았다.
5. S1 보류 → S1R 사전 등록(20:10, G2·진단 결과를 본 뒤)의 절차적 타당성.
6. G3 기준 (a)–(c)의 임계값과, 자기 view 목표 AE에 6차원 readout을 적용한 설계의 해석 범위.
7. L1, L2+ 층의 Bayes 하한이 없다는 점(Unresolved)과 witness 편향(오차 곱)의 처리.

### P6.7 Gate별 기록 (시간순)

**Phase 6 지시의 목표 (사용자 원문 요지)**
- Phase 5의 수학적 주장을 교정한다.
- 관측 정보의 존재(H1), 모델의 활용(H2), 공유 상태의 일관성(H3)을 분리해 검증한다.
- 우선순위: Mathematical validity → Identifiability → Experimental controls → Statistical inference → Scientific contribution.

**GPU**
- fai-L40S GPU 0, 1. 사용자가 10/29 00:39까지 연장했다(필요하면 사용자가 더 연장).
- 모든 작업은 `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0|1`로 실행한다.

**Gate G0 — 완료 (14:58)** → `results/notes/phase6_mathematical_errata.md`
- 점검 코드: `experiments/phase6/g0_checks.py` → `results/extra/phase6/g0/`
- E1: "정확히 2:1" → **적어도 2:1**(κ = 0에서는 Z₂×Z₂ 때문에 적어도 4:1). 섬유 크기는 Unresolved.
- E2: D(s)의 정의역. 역방향 흐름의 R⁶ 전역 존재는 증명되지 않았다. D는 X_T = Φ^T(R⁶)(T ≥ 0.35)와 A_κ 위에서만 정의한다.
- E3: Bayes 명제(명제 2, 3, 6)는 추정량의 기대 차이에 대한 정리가 아니다.
  - "κ = 0에서 B − A = 0이어야 한다"는 틀렸다. PR §7의 "모순" 조항도 틀렸다.
  - **새 명제 E3.1:** κ = 0, 독립 donor이면 E[B − Sham] = 0이 **추정량 수준에서 정확히** 성립한다.
- E4: 명제 3의 독립성은 고정 t에서는 정확하다. 시간 평균에서는 정상성 근사다.
- E5: L_j ≥ 2는 개수 기반 탐색적 층이다. "허용(식별가능) 마스크"라고 부르지 않는다.
- E6: **Phase 5 Sham donor는 다른 복제본/다른 test 대상의 실제 궤적이었다.**
  - B − Sham 복제본 대비는 독립이 아니다(κ = 1, p = 0.7에서 순환 ρ̂₁ = +0.43).
  - t-CI는 확증 근거가 아니다. 수치는 보존했다.
- E7: **Gate F MV-shift는 past-only 대조가 아니다.**
  - target view에 따라 다른 view 입력의 25–74%(Beijing)가 원래 시각 기준 미래(≥ 14일)다. 다른 view의 랩 경계는 제외되지 않았다.
  - 스트레스 실험으로만 인용한다. 공정 대조(MV-lag)는 제안만 했고 미실행이다.
- E8: 판정 라벨을 분리한다(방향 검출 / δ / 동등성).
- E9: MF §4의 "충분하다"를 "개수 조건만 만족"으로 고친다.

**Gate G1 — 완료** → 프로토콜 `results/notes/phase6_g1_protocol.md`(15:08 고정, 해시 `results/extra/phase6/PROTOCOL_FREEZE_g1.txt`)
- 새 수학(Verified math):
  - 생성기 법칙의 Γ×Γ, P 대칭(SRB 가정 불필요).
  - **L0 층에서 R*(U|L0) = E[y²]가 정확히 성립한다.** 따라서 임의의 고정 예측기 f로 Δ*_L0 ≥ E[y²|L0] − R(f|L0)이고, 이것은 추정 오차 가정 없는 통계적 하한이다.
  - Δ* ≥ p⁸ Δ*_L0.
  - 교차적합 witness의 편향 = 두 추정 오차의 곱.
- 코드: `experiments/phase6/g1_info.py`(κ ∈ {0, 1} × p ∈ {0, 0.3, 0.7}, 6개 작업). 출력: `results/extra/phase6/g1/`.
- **G1 완료 (15:27)** → `results/notes/phase6_g1_results.md`. 분석: `python experiments/phase6/analyze_g1.py`.
  - **κ = 1, p = 0.7: Δ*_L0 ≥ 0.032(단측 95%, test 궤적 32개), 따라서 Δ* ≥ 0.0019 > 0** [Verified (math) + 통계적 신뢰하한].
  - 정확한 null 넷(κ = 1 donor V, κ = 1 U 단독, κ = 0 V, κ = 0 Vc)은 모두 ≤ 0이다.
  - L0c0(x_o(t)도 결측)에서도 LCB 0.027이다. 이 정보는 순간 항등식이나 현재값이 아니라 **상대 view 지연 관측**에서 온다.
  - L1, L2+의 Bayes 개선은 Unresolved다. empirical 이득은 0.0006–0.003으로, null보다는 크다.
  - R*(U) ≥ p⁸ = 0.0576: 자기 창 Bayes 위험의 73% 이상이 대칭 모호성(L0)에서 온다.
  - 구조 감사: Phase 5 raw-MLP의 실패(joint가 더 나쁨)를 재현했고, 원인은 추정량이다(표본 수 + 고정 마스크). 새 마스크 증강 체제에서는 κ = 1 joint가 낫다(−0.005).
  - 모든 G1 예측기는 y로 학습한 Oracle-level 진단이다. AE 성능과 섞지 않는다.

**Gate G2/G3 — 완료** → 프로토콜 `results/notes/phase6_g2_g3_protocol.md`(15:04 고정, 해시 `PROTOCOL_FREEZE_g2g3.txt`)
- 새 독립 궤적(seed base 30261029, `experiments/phase6/gen6.py`, `results/extra/phase6/data/`).
- 복제본 24개/조건. 복제본마다 train/val/test 대상과 donor가 모두 독립이다. test 8개/복제본.
- Arm: A, Aslot(4-slot 용량 통제 own-only), B, Bcur, Sham × j = 1, 2. 조건 κ ∈ {0, 1} × p ∈ {0.3, 0.7}. 학습 960개.
- 주 대비 S1: **B − Sham (κ = 1, p = 0.7)**. 고정 순서는 S2(DiD p = 0.7) → S3(κ = 1, p = 0.3).
- 음성 대조: κ = 0의 B − Sham(정확히 0이 기대됨). δ = 0.02는 유지.
- G3: 공유 6차원 MLP readout, 독립 마스크 5개, 마스크만으로 정한 층과 Oracle σ_min 층을 분리, raw 기준선.
- 학습 lane: `results/extra/phase6/runs/lanes/main_lane{0..23}.log`(15:02 시작, 24 lane).
- 평가: `experiments/phase6/eval_sched6.py` → `results/extra/phase6/eval/`. Oracle Jacobian: `results/extra/phase6/jac/`.
- 테스트: `experiments/phase6/tests/test_phase6.py` 9/9 PASS(학습 전).
- 실행 중 확인된 사항:
  - 처음 정한 seed base(20261029)는 일부 test donor 시드가 Phase 5 κ = 1 시드와 겹쳤다. 테스트가 이를 잡았고, base를 30261029로 바꿔 Phase 6 자료를 전부 다시 생성했다. 이 자료는 그때까지 아무 데서도 쓰이지 않았다.
  - 복제본 수는 16에서 24로 늘렸다. 복제본마다 test 집합이 독립이라 복제본 간 SD가 커질 수 있어서다(검정력 근거는 프로토콜 §4). 두 변경 모두 학습 시작 전에 했다.
- **G2/G3 완료 (19:24)** → `results/notes/phase6_g2_g3_results.md`. 분석: `python experiments/phase6/analyze6.py` → `results/extra/phase6/analysis/`.
  - 무결성: 960 학습 rc = 0, 상한 도달 0, 비유한 0, md5 하나(`493f0b7f`). 평가 96/96.
  - S1 B − Sham(κ = 1, p = 0.7) = −0.0070 [−0.0116, −0.0024], 19/24. S2 DiD = −0.0132 [−0.019, −0.007]. S3(κ = 1, p = 0.3) = −0.0151 [−0.0162, −0.0139], 24/24. 모두 δ = 0.02 미만이다.
  - **음성 대조 κ = 0, p = 0.7이 실패했다:** B − Sham = +0.0062 [+0.0022, +0.0101], 20/24 양수(정확한 부호 검정 p ≈ 0.0015). 사전 규칙에 따라 **S1 결론은 보류**한다. κ = 0, p = 0.3 대조는 통과했으므로 **S3는 해석 가능한 독립 확증**이다.
  - 사후 진단(결합 적분 J 대 분리 적분 S, 학습 192개, `experiments/phase6/diag/`, `results/extra/phase6/diag_k0/`, 20:07 완료): J −0.0007 [−0.0060, +0.0046], S −0.0003 [−0.0054, +0.0047]. 수치 결합 가설은 기각했고, 원인은 Unresolved다.
  - **사전 등록 S1R**(프로토콜 §10, 20:10 고정, 학습 192개, `experiments/phase6/s1r/`, `results/extra/phase6/s1r/`, 20:48 완료):
    - κ = 1 B − Sham = **−0.0104 [−0.0141, −0.0068], 23/24**
    - κ = 0 대조 = +0.0009 [−0.0034, +0.0051], 통과
    - → **S1 독립 확증**(δ 미만)
  - 원래 H2(B − A, κ = 1, p = 0.7) = +0.0123 [0.0085, 0.0161]. 독립 표본에서도 B가 A보다 나쁘다. **지지되지 않는다.**
  - G3: 사전 기준(RMSE_s6 ≤ 0.2 ∧ 마스크 간 SD ≤ 0.1 ∧ raw보다 우수)을 만족한 AE 잠재가 **없다.**
    - 자기 목표 AE의 잠재는 상대 하위계를 거의 버린다(κ = 0에서 상대 RMSE 1.0, κ = 1에서 B만 0.42 / 0.92).
    - raw 결합 지연 관측 readout은 6차원을 p = 0.3에서 0.08, p = 0.7에서 0.37로 복원한다.
    - p = 0.7 오차의 대부분은 마스크 간 변동이다.

**재현 명령 (Phase 6)**
- `PYTHONPATH=.pydeps:. python experiments/phase6/gen6.py`
- `python experiments/phase6/tests/test_phase6.py`
- lane: `experiments/phase6/run_lane6.sh GPU results/extra/phase6/runs/lanes/main_part_Q.txt LOG`
- `python experiments/phase6/jac6.py 12`
- `python experiments/phase6/eval_sched6.py 4`
- `python experiments/phase6/g1_info.py K P`
- `python experiments/phase6/g0_checks.py`
- 분석: `python experiments/phase6/analyze_g1.py`, `python experiments/phase6/analyze6.py`, `python experiments/phase6/s1r/analyze.py`
- 사후 진단: `python experiments/phase6/diag/k0_gen.py 56` → `experiments/phase6/diag/run_lane_diag.sh` → `experiments/phase6/diag/k0_eval_loop.sh`
- S1R: `python experiments/phase6/s1r/gen.py 56` → `experiments/phase6/s1r/run_lane.sh GPU part LOG` → `experiments/phase6/s1r/eval_loop.sh` → `experiments/phase6/s1r/analyze.py`
- 모든 Python 명령은 `PYTHONPATH=.pydeps:.`와 `~/.conda/envs/reef_gpu/bin/python`으로 실행한다.

**코드 버전:** Git 저장소가 아니다. 파일 해시는 `results/extra/phase6/PROTOCOL_FREEZE_*.txt`, `results/extra/phase6/diag_k0/FREEZE.txt`, `results/extra/phase6/s1r/FREEZE.txt`에 있다. AE 학습 1,344개의 code_md5는 모두 `493f0b7f`다(행별 `runs/rows/*.csv`). Phase 5 코드와 결과는 수정하지 않았다(`experiments/phase6/`는 Phase 5 모듈을 import만 한다).

## 1. 연구 정체성

**공식 AIM**
> 완전 관측 변수 없이 다변량 시계열의 결측을 복원하는 동역학 기반 대치 프레임워크. Takens 정리가 시사하듯 모든 변수의 지연 매장이 일관되게 사상되는 공유 잠재 상태를 학습한다.

**중심 질문**
- 여러 불완전 지연 관측을 통합해, 기준 변수 없이 기저 동역학 상태의 일관된 표현을 학습할 수 있는가?

**현재 가설** (`results/notes/phase5_hypothesis_protocol.md`, 10:50 고정, 변경 기록 §9)
- **H1 (관측 수준 상보성):** κ = 1, p = 0.7에서 상대 view가 자기 hidden y_j에 대해 제곱오차 정보를 더한다.
- **H2 (주 가설, 학습 활용):** 상대 view를 입력으로 받는 AE 잠재(Arm B)가 자기 하위계만 받는 AE 잠재(Arm A)보다 y_j를 더 잘 decoding하게 한다. 두 Arm의 복원 목표는 같다.
- **H3 (공유 상태 일관성):** 하나의 readout이 허용 마스크(L_j ≥ 2)들에서 정확하고 안정적이다.
- **음성 대조:** κ = 0에서 H1과 H2의 개선은 0이어야 한다.

## 2. 수학적 기초 (`results/notes/phase5_mathematical_foundations.md`)

**정의**
- 상태공간: R⁶. 흡수 공이 존재하고(증명함), 대역 끌개 A_κ는 프랙탈이며 다양체가 아니다.
- 관측: x1, z1, x2, z2의 좌표 사영. generic하지 않다.
- 지연: m = 8, τ = 0.05.
- 마스크: 전체 격자에서 항목별 MCAR을 만든 뒤 창을 자른다.

**증명한 명제**
- 명제 1: 결정론적 식별 불가능성(점별).
- 보조정리 S: Γ×Γ와 P는 모든 κ에서 대칭이고, Γ×Id는 κ = 0에서만 대칭이다.
- 따름정리 1: z-only 마스크는 모든 κ에서 전역 2:1이다.
- 따름정리 2: κ = 0, x_j 미관측이면 상대 view와 무관하게 부호를 식별할 수 없다.
- 따름정리 3: 대칭 측도 하에서 해당 층의 Bayes 추정은 0이다.
- 명제 2: L² 사영 항등식. 조건부 의존성만으로는 위험이 줄지 않는다는 반례 포함.
- 명제 3: κ = 0에서 상대 view의 Bayes 개선은 0이다. 곱 측도와 MCAR 가정이 필요하다.
- 명제 5: y_j = x_j + (ẋ_j − κ(x_o − x_j))/σ. κ = 1에서는 상대 view의 **현재 값**만으로 자명한 이득이 생길 수 있다.
- 명제 6: 잠재는 원 입력보다 정보를 늘리지 못한다(자료처리 부등식).
- §7: H3 정의. 공유 readout을 쓰고, 잠재 재매개변수화에 불변이다. 잠재의 일치는 필요조건이 아니다.

**알려진 반례**
- z-only 창은 국소적으로 full-rank이지만 전역 비단사다(Gate C에서 수치 확인).
- h±(Phase 4)도 같은 성격의 반례다.

**국소 vs 전역**
- R⁶ 기준의 full rank는 근방 단사를 함의한다.
- 전역 단사, 균일 Lipschitz 역, 미분동형은 증명되지 않았다.

**미해결** (MF §8)
- κ = 1의 SRB 측도와 대칭.
- κ = 1, L0 층에서 부호 식별 여부.
- 좌표 관측의 전역 단사성.
- encoder의 단사성.

## 3. 저장소와 코드 상태

**Git과 경로**
- **Git: 저장소가 아니다**(`git status` → not a git repository). 버전은 파일별 code_md5로 기록한다.
- 루트: `/home/minju/faicpaston/Imputing_Missing_Data`
- Python: `~/.conda/envs/reef_gpu/bin/python`, `PYTHONPATH=.pydeps:.`
- 원본 공통 모듈: `src/` (수정하지 않음).
- 이전 실험: `experiments/{fdr, coupled, aim_autonomous, external}`, `results/extra/phase3*/phase4*`.

**Phase 5 코드: `experiments/phase5/`**

| 파일 | 역할 |
|---|---|
| `gen_data.py` | 독립 궤적 생성 |
| `obs_audit.py` | Gate C |
| `core.py` | Arm 정의, 자료 조립, ArmModel(FDR-Learned, 입출력 view 분리), 직렬 인코딩 |
| `train.py` | Arm 하나를 학습 |
| `run_lane.sh` | setsid lane. 마감 시각 guard 포함 |
| `evaluate.py` | probe, H3, 동역학, 대치 |
| `eval_scheduler.py` | 증거 기반 평가 실행기 |
| `h1_capacity.py` | H1 용량 민감도 |
| `analyze.py` | 사전 등록된 분석 |
| `analyze_posthoc.py` | **사후 탐색**(B − Sham, κ DiD). 확증 근거로 쓰지 않음 |
| `external.py` | Gate F 전처리, 학습(MV/MVshift/SV_k), 기준선, 채점 |
| `analyze_external.py` | Gate F 사전 등록 분석(seed별 주 블록 bootstrap) |
| `tests/test_phase5.py`, `tests/test_external.py` | 무결성 테스트 8 + 3개, 모두 통과 |

**Phase 5 자료와 결과: `results/extra/phase5/`**
- `data/k{κ}_id{j}.npz`: κ ∈ {0, 1}. train 0–7(20k), val 100–107(5k), test 200–209(5k).
- `gateC/`: 국소 Jacobian, 대칭, 전역 모호성, 물리 기준.
- `runs/{ckpt, logs, rows, lanes}`: 학습 산출물.
- `eval/`, `h1/`, `analysis/`(사후 탐색은 `analysis/posthoc_exploratory.csv`).
- `external/`: Gate F 블록별 SSE/N npz, `external/analysis/{contrasts,levels,summary}.csv`.
- 전처리 자료: `Data/external/{beijing,jena}/processed/*.npz`(원자료는 해시로 무변경 확인).

**외부 자료**
- `Data/external/{jena, appliances, beijing}/raw` (읽기 전용).
- 감사: `results/notes/phase5_external_dataset_audit.md`.

## 4. 완료한 작업 (Phase 5, 2026-10-28)

- **Gate A** 수학 문서 작성.
- **Gate B** 기존 코드 점검(§6) + 새 코드 테스트 8개.
- **Gate C** 관측 수준 감사(`phase5_observability_information_audit.md`).
- **Gate D** 파일럿: κ = 1, p = 0.7, r = 0의 9 Arm.
  - 버그 2개를 수정했다: A2의 출력 인덱스, lane의 rc 기록.
  - 학습은 안정적이었다: 비유한 0, 상한 도달 0, 42–160초.
  - test 수치는 보지 않았다.
- **Gate E 완료** (12:21): 학습 304개(모두 rc = 0, 비유한 0, 상한 도달 0, 34.9 GPU·h), 평가 36/36, H1 용량 4개, 사전 등록 분석.
- **Gate F 완료** (12:18): Beijing, Jena × p {0.3, 0.7} × seed 3 × (MV, MVshift, SV_k), 102개 rc = 0, 기준선 포함.
- 재실행 명령:
  - `PYTHONPATH=.pydeps:. python experiments/phase5/analyze.py`
  - `python experiments/phase5/analyze_external.py`
  - `python experiments/phase5/analyze_posthoc.py`

**Gate E/F 핵심 결과** (상세: `phase5_controlled_experiment_results.md`)
- **H2 주 대비 B − A (κ = 1, p = 0.7): +0.0137, t-CI [−0.0015, +0.0288], 1/8 → inconclusive. 지지되지 않음.** 점추정은 반대 방향이다.
- κ = 1, p = 0.3: B − A = −0.0128(8/8). 검출되지만 δ = 0.02보다 작다.
- κ = 0 음성 대조: B − A = +0.023(p = 0.7). B가 나쁘다.
- Sham − A = +0.020 ~ +0.029(p = 0.7). **입력 열 추가 자체의 비용**이다.
- 사후 탐색: κ = 1에서 B − Sham = −0.015(8/8), κ = 0에서는 약 0. 결합 정보는 작게 쓰이지만 입력 비용에 가려진다. **확증 아님.**
- L0 층(κ = 1, p = 0.7): B − A = −0.028(8/8). 그러나 RMSE가 약 1.0이라 거의 복원되지 않는다.
- p = 0.3의 L0 층은 표본이 j당 2–3개라 해석할 수 없다.
- H1: raw_joint는 own보다 나쁘다. 폭을 키우면 더 나빠진다(추정량 실패, DPI상 정보는 음수가 아님). → Bayes 수준은 Unresolved.
- H3: y_j 공유 readout은 p = 0.3에서 정확하다(약 0.04). p = 0.7에서는 마스크 간 분산이 약 0.13–0.18이고, s_j의 ridge 복원 오차는 0.44 이상이다. 강한 H3는 기각.
- latent가 raw 특징보다 낫다(전 조건 8/8). DPI상 정보 생성이 아니라 표현 효율이다.
- 학습 seed 변동(약 ±0.01)이 주 효과 크기와 비슷하다.
- **Gate F 사전 기준 충족:** Beijing p = 0.7에서 MV − MV-shift = −0.137, 3/3 seed CI < 0. g가 길수록 이득이 커진다(g ≥ 8에서 −0.386).
  - Jena에서도 모두 음수다.
  - 단일 궤적이다. past-only MV는 미래를 쓰는 선형 보간보다 나쁘다.

**Gate C 주요 결과**
- Γ×Γ는 κ = 1에서 정확한 대칭이다(잔차 0). Γ×Id는 1 시간단위 안에 잔차 30이다.
- z-only 이웃의 49–50%가 y의 부호가 반대다.
- κ = 1 물리 항등식: x_o(t)를 쓰면 y 오차가 0.113 → 0.061이다(과거만 쓰는 2차 차분). 효과 크기 δ = 0.02보다 크다. 즉 **κ = 1의 상대 view 이득은 순간 항등식으로 예상되는 결과다.**
- κ = 1, 자기 창 L0의 y1 국소 증폭은 168이다. 상대 view를 더하면 5.4(MCAR) 또는 0.53(완전)이다.
- κ = 1 궤적마다 부호 점유율이 0.34–0.70으로 크게 다르다. 그래서 test 궤적 10개를 쓴다.

## 5. 알려진 오류와 무효화된 결과

**이전 Phase에서 발견된 문제 (memory와 notes)**
- FPRM 테스트를 다시 돌리지 않은 문제.
- GP plateau.
- P9 오류.
- 이전 held-out ELBO가 조건부 ELBO가 아니었던 문제.
- Phase 3C의 "FDR 일관성 우위"는 관측 좌표에서 나온 것이었다(3D-1).
- future-y 분할 경계 누출(영향 ≤ 2.3e-4).
- Phase 4 view 제거 평가가 OOD였다. **이번 Arm A/B 설계로 대체했다.**

**Phase 5에서 발견된 것**
- A2 출력 인덱스 버그(파일럿에서 발견하고 수정, 회귀 테스트 추가).
- lane rc 기록 버그(수정).

**설계로 해결한 점**
- **모델 선택에 참값을 쓰지 않는다.** val 궤적에서 관측 항목을 가려 기준으로 쓴다. 이전 Phase는 평가 결측 위치의 참값으로 조기 종료했다.

**남은 우려**
- Arm마다 모수 수가 다르다(A 31.5k, B 46.3k, C 57.8k).
- Sham은 κ = 1에서 분포 이동이 있다.
- **입력 열 비용이 B − A를 지배한다**(Sham − A > 0). 이를 보정하는 비교(B − Sham)는 사후 탐색일 뿐이다.
- 조기 종료 기준(val 관측 재구성)은 y_j decoding의 대리 지표가 아니다.

## 6. Gate B — 기존 코드 점검 요약

| 항목 | 결과 |
|---|---|
| 마스크 생성 | 전체 격자 MCAR → 창 절단. 겹치는 창의 일관성 OK [Verified (code)] |
| delay 정렬 | lag k = index k, past-only, 앞쪽 패딩은 미관측으로 처리 [Verified (code), Phase 5 past-only 테스트] |
| 손실 | FDR 다중도 보정 1/c(u)는 기존 tests로 확인. Phase 5에서는 목표 열에만 적용함을 테스트로 확인 |
| 정규화 | train 관측 항목만 사용 [Verified (code)] |
| view 제거 | Phase 4는 OOD였다 → Arm 설계로 대체 |
| 관측/결측 위치 혼합 | Phase 3D-1에서 발견. Phase 5 대치는 결측 위치만, probe는 마스크와 무관한 상태 목표 |
| 분할 경계 | Phase 5는 독립 궤적으로 분리해 경계 문제를 없앴다. 동역학 probe도 같은 궤적 안에서 t + 5만 쓴다 |
| FDR 다중도 가중 | lag-0의 실효 가중이 약 12%다(3D-1). Phase 5 주 지표는 probe라서 lag-0 대치는 부차 지표다 |

## 7. 대기 중인 작업
- 실행 중인 GPU 작업은 없다. 승인됐지만 실행하지 않은 것도 없다.
- **제안 (미승인, 새 사전 등록 필요):**
  1. 새 독립 복제본(train id 8–15)에서 **B − Sham을 주 대비**로 사전 등록해 확증한다.
  2. H1 하한을 구조화 추정량(마스크 패턴별 모델, 물리 항등식 기반)으로 다시 시험한다.
  3. Gate F에 양방향(비 past-only) 변형을 두고, 미래 사용 기준선과 공정하게 비교한다.

## 8. 과학적 해석 (Gate E/F 후)
- **H2: 지지되지 않음**(사전 등록 주 대비 inconclusive, 점추정 반대 방향).
- **H1:** 검출되지 않음(추정량의 한계). Bayes 수준은 Unresolved.
- **H3:** 강한 형태는 기각. 약한 형태(p = 0.3에서 y_j)만 성립.
- **κ = 0 대조:** 정보 0과 일관된다(B ≈ Sham).
- **실제 자료:** 정렬된 multi-view의 예측 이득은 경험적으로 확인됐다. 숨은 상태 복원의 증거는 아니다.
- **지지되지 않는 주장:**
  - 미분동형 대응
  - 전역 식별가능성
  - "잠재가 상태를 발견했다"
  - "multi-view 결합이 coupled 계에서 hidden 상태 복원을 개선한다"(p = 0.7)

## 10. 독립 수학 검증 패키지 (2026-10-28 13:11 생성)
- 위치: `results/review_packages/phase5_20261028/`
  - `phase5_review_documents.zip`: 문서 5개(MF, protocol, results, observability audit, 이 handover의 12:37 버전 = 이 §10 추가 전) + `FILE_INDEX.md`.
  - `phase5_verification_bundle.zip`: 1,016개 파일 + `FILE_INDEX.md` + `MANIFEST.json`(파일별 sha256·크기·mtime·역할·가설).
    - 원본 평가 CSV(eval 144개), 사전 등록/사후/Gate F 분석 결과, H1 용량, Gate C, Gate F npz, 학습 rows/logs/lanes, 분석·학습·평가 코드, 테스트 코드, 의존 모듈 4개.
    - 제외: 궤적 npz 52개와 외부 전처리 npz(해시만 기록), 체크포인트 304개.
  - `SHA256SUMS`, `build_bundle.py`(패키지 생성 스크립트, 읽기 전용 복사만 수행).
- 생성 시 재현 점검(CPU): ZIP만 풀어 `analyze_posthoc.py`, `analyze_external.py` 실행 → 원본 CSV와 바이트 동일. 무결성 테스트 11/11 PASS(원 프로젝트, 13:13).
- 기존 코드·결과·문서는 수정하지 않았다. 새 연구 결론은 작성하지 않았다. GPU는 사용하지 않았다.

**미해결 검토 사항 (외부 검토자에게 확인 요청; 기존 문서에 이미 기록된 항목)**
1. 명제 3(κ = 0 Bayes 이득 0)의 가정: 곱 측도, MCAR, 마스크 독립 — 유한 길이 궤적·공유 test 마스크에서 적용 범위.
2. 명제 2 반례와 H2 판정의 연결: 조건부 의존성 ≠ 위험 감소.
3. κ = 1 SRB 측도의 대칭과 L0 층 부호 식별 여부(MF §8, 미해결).
4. 좌표 관측·encoder의 전역 단사성(국소 rank만 수치 확인).
5. H1: 원시 특징 MLP의 악화가 추정량 실패인지(DPI 논증)와 정보 하한 추정 방법.
6. H2 판정 함수가 TOST를 OPPOSITE보다 먼저 검사하는 순서의 타당성.
7. 사후 탐색 B − Sham, κ DiD(Welch)의 해석 범위 — 확증 아님.
8. Sham의 κ = 1 분포 이동, Arm 간 모수 수 차이(A 31.5k / B 46.3k / C 57.8k).
9. 참값 없는 조기 종료 기준과 y_j decoding의 관계; 학습 seed 변동(약 ±0.01).
10. p = 0.3 L0 층 표본 2–3개(해석 불가)와 층별 다중성 미보정.
11. Gate F: 단일 궤적, seed 3개, 주 블록 bootstrap; MV-shift(14k일)가 계절 정렬도 깨는 점; past-only 대 미래 사용 기준선.

## 9. 다음 세션 지시 (Phase 5 시점 기록. **Phase 6 이후로는 §P6.5–P6.6을 따른다**)
- **현재 상태(13:15 당시):** 독립 수학 검토 대기. 검토 결과가 오기 전에는 새 GPU 학습·추가 실험을 시작하지 않는다(사용자 지시 2026-10-28 13:08).
- **먼저 읽을 파일:**
  1. 이 파일
  2. `phase5_mathematical_foundations.md`
  3. `phase5_hypothesis_protocol.md`
  4. `phase5_observability_information_audit.md`
  5. `phase5_controlled_experiment_results.md`
- **하지 말 것:**
  - 프로토콜을 사후에 바꾸는 것
  - 불리한 복제본을 제외하는 것
  - 원본 자료, 이전 체크포인트, 이전 결과를 수정하는 것
  - 미분동형을 주장하는 것
  - 예약 없이 GPU를 쓰는 것
