# Phase 9 verification bundle (2026-10-31)

Contents
- docs/: the 7 Phase 9 documents, the test log, and the handover
- code/phase9/: Phase 9 code and tests
- code/deps/: the frozen Phase 5–8 modules it imports
- freeze/: PROTOCOL_FREEZE_p9*.txt and FREEZE_CHANGES.md
- analysis/: pilot and main analyses (confirmatory sequence, paired contrasts, gates)
- eval/: replicate-level evaluation sums, all 480 files
  - imp: missing-position SSE
  - ret: retrieval sums
  - acc: R1 / O_raw SSE
  - mv: mask variance
- runs/rows: training records
- runs/logs: per-epoch curves, including the 3 L_tow divergences at κ=0, p=0.3
- jena/: real-data results (descriptive)
- audit/: independent verification script and outputs (pilot 11/11, main 14/14)

Re-check the confirmatory decision without server access: aggregate eval/main_k1.0_p0.7_r*_imp.csv.gz (stratum 'all'; pooled RMSE = sqrt(Σsse/Σn) per rep and method) and eval/main_k1.0_p0.7_r*_ret.csv.gz (rho_ret = Σsum_nn / Σsum_rand per rep and feat). Then apply the protocol §4 fixed sequence: one-sided t, α = 0.025, n = 24.

NOT included (regenerable or large; hashes in FULL_DATA_LIST.txt):
- results/extra/phase9/data: 600 trajectories. Regenerate with gen9.py; seed rule s0_of(κ, id), ids 200000+.
- runs/ckpt: AE checkpoints, 115 MB
- jena/ckpt
- Phase 8 oracles used as diagnostics: hashes in freeze/PROTOCOL_FREEZE_p9.txt
